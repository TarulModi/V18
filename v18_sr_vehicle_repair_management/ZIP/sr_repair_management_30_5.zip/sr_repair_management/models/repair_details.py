# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class RepairDetails(models.Model):
    _name = "repair.details"
    _description = "Repair Details"
    _inherit = ['mail.thread']
    _rec_name = "name"

    repair_id = fields.Many2one('vehicle.repair.order')
    name = fields.Char('Name', required=True, tracking=True)
    description = fields.Text("Description", copy=False, tracking=True)
    attachment_ids = fields.Many2many('ir.attachment', string="Images")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in_diagnosis', 'In Diagnosis'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
    ], default='draft', copy=False, tracking=True)
    diagnosis_id = fields.Many2one('repair.diagnosis', string="Diagnosis")
    checklist_id = fields.Many2one('repair.checklist', string="Checklist")

    # @api.model_create_multi
    # def create(self, vals_list):
    #     records = super().create(vals_list)
    #     for record in records:
    #         if record.repair_id and record.repair_id.diagnosis_id:
    #             self.env['repair.checklist'].create({
    #                 'repair_id': record.repair_id.id,
    #                 'repair_details_id': record.id,
    #                 'diagnosis_id': record.repair_id.diagnosis_id.id,
    #                 'name': record.name,
    #                 'description': record.description,
    #                 'attachment_ids': [(6, 0, record.attachment_ids.ids)],
    #                 'user_id': self.env.uid,  # Or set a default technician
    #             })
    #     return records
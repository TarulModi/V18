# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from datetime import datetime, timedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class AcademicYear(models.Model):
    _name = "academic.year"
    _inherit = ['mail.thread']
    _description = "Academic Year"
    _rec_name = "name"

    name = fields.Char(string="Name", tracking=True, translate=True)
    term_structure_id = fields.Many2one("term.structure", string="Term Structure", tracking=True)
    start_date = fields.Date(string="Start Date", tracking=True)
    end_date = fields.Date(string="End Date", tracking=True)
    academic_terms_ids = fields.One2many("academic.terms", "academic_year_id")

    @api.constrains('start_date', 'end_date')
    def check_dates(self):
        for record in self:
            if record.start_date > record.end_date:
                raise ValidationError(_("End Date cannot be set before Start Date."))

    def generate_academic_terms(self):
        for record in self:
            if record.term_structure_id:
                term_count = record.term_structure_id.no_of_term
                start_date = fields.Date.from_string(record.start_date)
                end_date = fields.Date.from_string(record.end_date)

                # Delete existing academic terms
                record.academic_terms_ids.unlink()

                # Calculate the duration of each term
                term_duration = (end_date - start_date) // term_count

                # Generate academic terms and create records
                for i in range(term_count):
                    term_start_date = start_date + timedelta(days=i * term_duration.days)
                    term_end_date = term_start_date + timedelta(days=term_duration.days - 1)

                    # Create new academic term
                    self.env['academic.terms'].create({
                        'academic_year_id': record.id,
                        'name': f"Term {i + 1}",
                        'start_date': term_start_date,
                        'end_date': term_end_date,
                    })
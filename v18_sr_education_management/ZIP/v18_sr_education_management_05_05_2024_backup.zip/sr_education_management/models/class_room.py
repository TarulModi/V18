# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class ClassRoom(models.Model):
    _name = "class.room"
    _inherit = ['mail.thread']
    _description = "Class Room"
    _rec_name = "name"

    name = fields.Char(string="Name", tracking=True, translate=True)
    division = fields.Char(string="Division", tracking=True, translate=True)
    medium_id = fields.Many2one("medium.medium", string="Medium", tracking=True)
    company_id = fields.Many2one("res.company", string="School", tracking=True, default=lambda self: self.env.company)
    employee_id = fields.Many2one("hr.employee", string="Teacher", tracking=True)
    capacity = fields.Integer(string="Capacity", tracking=True)
    total_student = fields.Integer(string="Total Student", tracking=True)
    available_student = fields.Integer(string="Available Student", tracking=True)
    class_number = fields.Char(string="Class Number", tracking=True, translate=True)
    student_ids = fields.One2many("class.student", "class_room_id", string="Students", tracking=True)
    subject_ids = fields.One2many("class.subject", "class_room_id", string="Subjects", tracking=True)

# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class Courses(models.Model):
    _name = "courses.courses"
    _inherit = ['mail.thread']
    _description = "Courses"
    _rec_name = "name"

    name = fields.Char(string="Name", tracking=True, translate=True)
    code = fields.Char(string="Code", tracking=True, translate=True)
    course_image = fields.Binary("Course Image", tracking=True)
    parent_id = fields.Many2one("courses.courses", tracking=True)
    description = fields.Text("Description", tracking=True)
    courses_grade_ids = fields.One2many("courses.grade", "courses_id")
    courses_subject_ids = fields.One2many("subject.subject", "courses_id")
    # subject_ids = fields.Many2many("subject.subject", "subject_course_rel", "course_id", "subject_id", string="Subjects")

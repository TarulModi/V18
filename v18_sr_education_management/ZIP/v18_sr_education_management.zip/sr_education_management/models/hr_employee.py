# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class Employee(models.Model):
    _inherit = "hr.employee"

    is_faculty = fields.Boolean(string="Is Faculty", tracking=True)
    # subject_ids = fields.Many2many("subject.subject", "subject_employee_rel", "employee_id", "subject_id",
    #                                string="Subjects")
    subject_ids = fields.One2many("employee.subject", "employee_id", string="Subjects")

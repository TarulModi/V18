# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class AddmissionDocVarify(models.TransientModel):
    _name = "admission.doc.varification"
    _description = "Admission Doc Varification"

    admission_id = fields.Many2one("admission.admission", string="Admission")
    documents_ids = fields.Many2many("documents.documents", "admission_id", string="Documents")

    @api.onchange('admission_id')
    def _onchange_admission(self):
        # On changing admission, fetch all related documents from that admission record
        self.documents_ids = self.admission_id.documents_ids

    def verify_doc(self):
        """
        Verify all documents. If no unverified documents remain,
        update the admission state to 'doc_verification'.
        """
        non_varify_doc = self.documents_ids.filtered(lambda doc: not doc.is_verified)
        if not non_varify_doc:
            self.admission_id.state = 'doc_verification'
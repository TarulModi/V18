# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class ClassRoom(models.Model):
    _name = "class.room"
    _inherit = ['mail.thread']
    _description = "Class Room"
    _rec_name = "name"

    name = fields.Char(string="Name", tracking=True, translate=True)
    division = fields.Char(string="Division", tracking=True, translate=True)
    medium_id = fields.Many2one("medium.medium", string="Medium", tracking=True)
    company_id = fields.Many2one("res.company", string="School", tracking=True, default=lambda self: self.env.company)
    employee_id = fields.Many2one("hr.employee", string="Teacher", tracking=True, domain=[('is_faculty', '=', True)])
    capacity = fields.Integer(string="Capacity", tracking=True)
    total_student = fields.Integer(string="Total Student", tracking=True, compute="_compute_student")
    available_student = fields.Integer(string="Available Student", tracking=True, compute="_compute_student")
    class_number = fields.Char(string="Class Number", tracking=True, translate=True)
    student_ids = fields.One2many("class.student", "class_room_id", string="Students", tracking=True)
    subject_ids = fields.One2many("class.subject", "class_room_id", string="Subjects", tracking=True)
    course_id = fields.Many2one("courses.courses", string="Course", tracking=True)

    @api.depends('capacity', 'student_ids')
    def _compute_student(self):
        for rec in self:
            rec.total_student = len(rec.student_ids.ids)
            rec.available_student = rec.capacity - rec.total_student

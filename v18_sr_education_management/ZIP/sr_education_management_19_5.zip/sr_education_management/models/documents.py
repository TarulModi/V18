# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class Documents(models.Model):
    _name = "documents.documents"
    _inherit = ['mail.thread']
    _description = "Documents"
    _rec_name = "name"

    admission_id = fields.Many2one("admission.admission", string="Admission", tracking=True, copy=False)
    name = fields.Char("Name", tracking=True)
    documents = fields.Binary("Documents", tracking=True)
    student_id = fields.Many2one("student.student", string="Student", tracking=True, copy=False)

# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class Courses(models.Model):
    _name = "courses.courses"
    _inherit = ['mail.thread']
    _description = "Courses"
    _rec_name = "name"

    name = fields.Char(string="Name", tracking=True, translate=True)
    code = fields.Char(string="Code", tracking=True, translate=True)
    course_image = fields.Binary("Course Image", tracking=True)
    parent_id = fields.Many2one("courses.courses", tracking=True)
    description = fields.Text("Description", tracking=True)
    courses_grade_ids = fields.One2many("courses.grade", "courses_id")
    courses_subject_ids = fields.One2many("subject.subject", "courses_id")
    # subject_ids = fields.Many2many("subject.subject", "subject_course_rel", "course_id", "subject_id", string="Subjects")
    admission_ids = fields.One2many('admission.admission', 'course_id', 'Admissions')
    student_ids = fields.One2many('student.student', 'course_id', 'Students')
    admission_count = fields.Float('Admission Count', compute="_compute_addmission_count")
    student_count = fields.Float('Student Count', compute="_compute_student_count")
    employee_ids = fields.Many2many("hr.employee", "Faculty", compute="compute_employee")

    def compute_employee(self):
        for rec in self:
            timetable_days = self.env['timetable.days'].search([('timetable_id.course_id', '=', rec.id)])
            rec.employee_ids = [(6, 0, timetable_days.employee_id.ids)]

    @api.depends('admission_ids')
    def _compute_addmission_count(self):
        for rec in self:
            rec.admission_count = len(rec.admission_ids.ids)

    @api.depends('student_ids')
    def _compute_student_count(self):
        for rec in self:
            rec.student_count = len(rec.student_ids.ids)

    def action_open_admission(self):
        related_admission = self.admission_ids
        action = {
            'name': _("Related Admissions"),
            'type': 'ir.actions.act_window',
            'res_model': 'admission.admission',
            'view_mode': 'form',
        }
        if len(related_admission) > 1:
            action['view_mode'] = 'list,form'
            action['domain'] = [('id', 'in', related_admission.ids)]
            return action
        else:
            action['res_id'] = related_admission.id
        return action

    def action_open_student(self):
        related_student = self.student_ids
        action = {
            'name': _("Related Admissions"),
            'type': 'ir.actions.act_window',
            'res_model': 'student.student',
            'view_mode': 'form',
        }
        if len(related_student) > 1:
            action['view_mode'] = 'list,form'
            action['domain'] = [('id', 'in', related_student.ids)]
            return action
        else:
            action['res_id'] = related_student.id
        return action

    def action_open_class(self):
        return {
            'name': _("Class Room"),
            'type': 'ir.actions.act_window',
            'res_model': 'class.room',
            'view_mode': 'list,form',
            'domain' : [('course_id', '=', self.id)],
            'context' : {'default_course_id': self.id},
        }

    def action_open_timetable(self):
        return {
            'name': _("Timetable"),
            'type': 'ir.actions.act_window',
            'res_model': 'school.timetable',
            'view_mode': 'list,form',
            'domain': [('course_id', '=', self.id)],
            'context': {'default_course_id': self.id},
        }
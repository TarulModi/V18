# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################
from odoo import api, fields, models, _


class HospitalWardRoom(models.Model):
    _name = 'hospital.ward.room'
    _description = 'Hospital Ward Room'
    _rec_name = 'room_id'
    _inherit = ['mail.thread']

    ward_id = fields.Many2one('hospital.ward', string="Ward", required=True, ondelete='cascade', tracking=True)
    room_id = fields.Many2one('hospital.room', string="Room", required=True, ondelete='cascade', tracking=True)
    room_type = fields.Selection(related="room_id.room_type", string="Room Type", required=True, tracking=True)
    bed_count = fields.Integer(related="room_id.bed_count", string="Bed Count", required=True, tracking=True)
    is_available = fields.Boolean(string="Available", default=True, tracking=True)

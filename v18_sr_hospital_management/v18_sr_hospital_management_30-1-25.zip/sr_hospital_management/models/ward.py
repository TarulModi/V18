# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################
from odoo import api, fields, models, _


class HospitalWard(models.Model):
    _name = 'hospital.ward'
    _description = 'Hospital Ward'
    _rec_name = 'name'
    _inherit = ['mail.thread']
    
    name = fields.Char(string="Ward Name", required=True, tracking=True)
    ward_code = fields.Char(string="Ward Code", required=True, unique=True, tracking=True)
    capacity = fields.Integer(string="Total Capacity", required=True, tracking=True)
    room_ids = fields.One2many('hospital.ward.room', 'ward_id', string="Rooms", tracking=True)

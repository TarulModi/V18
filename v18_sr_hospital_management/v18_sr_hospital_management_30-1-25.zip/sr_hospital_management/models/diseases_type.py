# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################
from odoo import api, fields, models, _


class DiseasesType(models.Model):
    _name = 'diseases.type'
    _description = 'Diseases Type'
    _rec_name = 'name'
    _inherit = ['mail.thread']

    name = fields.Char(string="Name", required=True, tracking=True)
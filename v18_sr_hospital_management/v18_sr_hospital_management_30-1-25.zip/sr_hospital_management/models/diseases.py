# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################
from odoo import api, fields, models, _


class Diseases(models.Model):
    _name = 'diseases.diseases'
    _description = 'Diseases'
    _rec_name = 'name'
    _inherit = ['mail.thread']

    name = fields.Char(string="Name", required=True, tracking=True)
    diseases_type_id = fields.Many2one('diseases.type', string="Type", required=True, ondelete='cascade', tracking=True)
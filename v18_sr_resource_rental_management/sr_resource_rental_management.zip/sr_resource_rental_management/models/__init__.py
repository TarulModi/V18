# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from . import inherited_res_config_settings
from . import sr_rental_pricing
from . import inherited_res_company
from . import inherited_product_template
from . import inherited_sale_order
from . import inherited_stock_production_lot

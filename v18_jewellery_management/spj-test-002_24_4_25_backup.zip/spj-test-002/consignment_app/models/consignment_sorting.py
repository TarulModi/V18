from odoo import models, fields, api

class ConsignmentSorting(models.Model):
    _name = 'consignment.sorting'
    _description = 'Consignment Sorting'
    _rec_name = 'consignment_line_id'

    consignment_id = fields.Many2one('consignment', string="Consignment", required=True, ondelete='cascade')
    consignment_line_id = fields.Many2one('consignment.line', string="Consignment Line", required=True, ondelete='cascade')  # New field
    worker_id = fields.Many2one('hr.employee', string='Worker')
    date = fields.Datetime(string='Date', default=fields.Datetime.now, readonly=True)

    sorting_line_ids = fields.One2many('consignment.sorting.line', 'sorting_id', string='Sorting Lines')

    # --------------------start-----------------------
    product_id = fields.Many2one(
        'product.template',
        string='Product',
       related="consignment_line_id.product_id",
    )

    @api.model
    def default_get(self, fields):
        res = super(ConsignmentSorting, self).default_get(fields)
        active_id = self.env['consignment.line'].browse(self._context.get('active_id'))
        if active_id:
            res.update({
                'consignment_line_id': active_id.id,
                'consignment_id': active_id.consignment_id.id,
                'worker_id': self.env.user.id,
            })
        return res

    # -----------------end-------------------------------


class ConsignmentSortingLine(models.Model):
    _name = 'consignment.sorting.line'
    _description = 'Consignment Sorting Line'
    _rec_name = 'product_id'

    sorting_id = fields.Many2one('consignment.sorting', string='Sorting', required=True, ondelete='cascade')
    product_id = fields.Many2one(
        'product.product',
        string='Product',
        required=True, domain="[('id', 'in', available_product_ids)]",  # ✅ Restrict selection dynamically
    )
    available_product_ids = fields.Many2many(
        'product.product', compute='_compute_available_products', string=' ', store=False
    )
    # size_id = fields.Many2one(
    #     'product.attribute.value',
    #     string='Size',
    #     domain="[('attribute_id.name', '=', 'Size')]"
    # )
    primary_uom = fields.Many2one('uom.uom', string='Primary UOM', related='product_id.uom_id', readonly=True)
    secondary_uom = fields.Many2one('uom.uom', string='Secondary UOM')
    qty_weight = fields.Float(string='Quantity in Weight')
    qty_pcs = fields.Float(string='Quantity in Pieces')

    @api.depends('sorting_id.consignment_line_id.product_id')
    def _compute_available_products(self):
        """ Dynamically filter product variants based on selected product in Consignment Line """
        for line in self:
            if line.sorting_id.consignment_line_id.product_id:
                product_template = line.sorting_id.consignment_line_id.product_id
                variants = self.env['product.product'].search([('product_tmpl_id', '=', product_template.id)])
                line.available_product_ids = variants
            else:
                line.available_product_ids = False  # No variants available if no product selected

    @api.model
    def create(self, vals):
        res = super(ConsignmentSortingLine, self).create(vals)
        res._update_consignment_line()
        return res

    def write(self, vals):
        res = super(ConsignmentSortingLine, self).write(vals)
        self._update_consignment_line()
        return res

    def unlink(self):
        consignment_lines = self.mapped('sorting_id.consignment_line_id')
        res = super(ConsignmentSortingLine, self).unlink()
        consignment_lines._compute_sorted_values()  # Correct method name
        return res

    def _update_consignment_line(self):
        """Update consignment line values when sorting lines change"""
        for sorting_line in self:
            consignment_line = sorting_line.sorting_id.consignment_line_id 
            consignment_line._compute_sorted_values()  # Update sorted values

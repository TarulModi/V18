
from odoo import models, fields, api, _


class TreeManagement(models.Model):
    _inherit = 'tree.management'
    _order = 'id desc'

    receive_line_ids = fields.Many2many('job.receive.line', string="Job Receive Lines")
    next_work_center_id = fields.Many2one('mrp.workcenter', string='Next Work Center')
    job_issue_count = fields.Integer(string="# Job Issue", compute="_compute_job_issue_count")
    job_receive_count = fields.Integer(string="# Job Receive", compute="_compute_job_receive_count")

    total_casting_pcs = fields.Float("Total Casting PCS", compute="_compute_total_casting_pcs",
                                     store=True)
    total_casting_weight = fields.Float("Total Casting Weight", compute="_compute_total_casting_weight",
                                        store=True)
    sprue_scrap = fields.Float("Sprue Scrap")
    sprue_dust = fields.Float("Sprue Dust")
    sprue_loss = fields.Float("Sprue Loss")
    actual_conjunction = fields.Float("Actual Conjunction", compute="_compute_total_actual_conjunction",
                                      store=True)
    is_spure_allocate = fields.Boolean("Is Spure Allocate?", copy=False)
    is_spure_allocate_validate = fields.Boolean("Is Spure Allocate?", copy=False)

    @api.onchange('work_center')
    def onchange_workcenter_id(self):
        if self.work_center:
            self.tree_ids = [(5, 0)]
            job_receive_line_ids = self.env['job.receive.line'].search(
                [('job_receive_id.state', '=', 'issue'), ('workcenter_id', '=', self.work_center.id)])
            if job_receive_line_ids:
                self.receive_line_ids = [(6, 0, job_receive_line_ids.ids)]
            else:
                self.receive_line_ids = [(6, 0, [])]

    def action_issue_to_casting(self):
        result = super(TreeManagement, self).action_issue_to_casting()
        job_isse_line_list = []
        if self.tree_ids:
            for tree_id in self.tree_ids:
                if tree_id and tree_id.tree_management_id.mo_id:
                    tree_id.tree_management_id.mo_id.tree_id = self.id
                job_isse_line_list.append((0, 0, {
                    'production_id' : tree_id.mo_no.id,
                    'pcs' : tree_id.return_piece,
                    'issue_gross_weight' : tree_id.gross_weight,
                    'issue_net_weight' : tree_id.net_weight,
                    'tree_management_mo_id' : tree_id.id,
                }))
            if job_isse_line_list:
                job_issue_id = self.env['job.issue'].create({
                    'workcenter_id' : self.next_work_center_id.id,
                    'production_ids' : [(6, 0, self.tree_ids.mo_no.ids)],
                    'job_issue_line_ids' : job_isse_line_list,
                })
                if job_issue_id and job_issue_id.job_issue_line_ids:
                    for line in job_issue_id.job_issue_line_ids:
                        if line.tree_management_mo_id:
                            line.tree_management_mo_id.write({
                                'job_isse_line_id' : line.id,
                                'job_issue_qty' : line.pcs
                            })
                    job_issue_id.action_confirm()
        return result

    @api.depends('tree_ids.job_isse_line_id')
    def _compute_job_issue_count(self):
        for record in self:
            if record.tree_ids and record.tree_ids.job_isse_line_id:
                record.job_issue_count = self.env['job.issue'].search_count([('id', '=', record.tree_ids.job_isse_line_id.job_issue_id.id)])
            else:
                record.job_issue_count = 0

    def open_job_issue_record(self):
        action = self.env['ir.actions.actions']._for_xml_id('sr_job_card.action_job_issue')
        if self.job_issue_count >= 1:
            action['domain'] = [('id', '=', self.tree_ids.job_isse_line_id.job_issue_id.id)]
        return action

    @api.depends('tree_ids.casting_receive_line_id')
    def _compute_job_receive_count(self):
        for record in self:
            if record.tree_ids and record.tree_ids.casting_receive_line_id:
                record.job_receive_count = self.env['job.receive'].search_count(
                    [('id', '=', record.tree_ids.casting_receive_line_id.job_receive_id.id)])
            else:
                record.job_receive_count = 0

    def open_job_receive_record(self):
        action = self.env['ir.actions.actions']._for_xml_id('sr_job_card.action_job_receive')
        if self.job_receive_count >= 1:
            action['domain'] = [('id', '=', self.tree_ids.casting_receive_line_id.job_receive_id.id)]
        return action

    @api.depends('tree_ids.cst_rec_pcs')
    def _compute_total_casting_pcs(self):
        for record in self:
            record.total_casting_pcs = sum(record.tree_ids.mapped('cst_rec_pcs'))

    @api.depends('tree_ids.cst_net_weight')
    def _compute_total_casting_weight(self):
        for record in self:
            record.total_casting_weight = sum(record.tree_ids.mapped('cst_net_weight'))

    @api.depends('metal_tree_weight', 'total_casting_weight', 'sprue_scrap', 'sprue_dust', 'sprue_loss')
    def _compute_total_actual_conjunction(self):
        for record in self:
            actual_conjunction = (record.metal_tree_weight - record.total_casting_weight - record.sprue_scrap - record.sprue_dust - record.sprue_loss)
            record.actual_conjunction = actual_conjunction

    def action_spure_allocate(self):
        self.is_spure_allocate = True
        if self.tree_ids:
            for tree in self.tree_ids:
                if tree.cst_net_weight > 0 and self.total_casting_weight > 0:
                    ratio = tree.cst_net_weight / self.total_casting_weight
                else:
                    ratio = 0

                if ratio > 0 and self.actual_conjunction > 0:
                    mt_consumption = (ratio * self.actual_conjunction)
                else:
                    mt_consumption = 0

                if ratio > 0 and self.sprue_scrap > 0:
                    spure_scrap = (ratio * self.sprue_scrap)
                else:
                    spure_scrap = 0

                if ratio > 0 and self.sprue_dust > 0:
                    sprue_dust = (ratio * self.sprue_dust)
                else:
                    sprue_dust = 0

                if ratio > 0 and self.sprue_loss > 0:
                    sprue_loss = (ratio * self.sprue_loss)
                else:
                    sprue_loss = 0
                tree.write({
                    'ratio' : ratio,
                    'mt_consumption' : mt_consumption,
                    'spure_scrap' : spure_scrap,
                    'spure_dust' : sprue_dust,
                    'spure_loss' : sprue_loss,
                })

    def action_spure_allocate_validate(self):
        self.is_spure_allocate_validate = True

    def action_casting_done(self):
        result = super(TreeManagement, self).action_casting_done()
        if self.tree_ids:
            line_ids = self.tree_ids.mapped('job_isse_line_id')
            if line_ids:
                for line in line_ids:
                    line.button_start()
                    line.button_done()
        return result

    def action_sprue_cutting(self):
        result = super(TreeManagement, self).action_sprue_cutting()
        job_receive_line_list = []
        if self.tree_ids:
            for tree_id in self.tree_ids:
                if tree_id and tree_id.mo_sprue_cut:
                    tree_id.mo_sprue_cut.tree_id = self.id
                if tree_id and tree_id.job_isse_line_id:
                    job_receive_line_list.append((0, 0, {
                        'job_issue_line_id' : tree_id.job_isse_line_id.id,
                        'tree_management_mo_id': tree_id.id,
                    }))
            if job_receive_line_list:
                job_receive_id = self.env['job.receive'].create({
                    'workcenter_id' : self.next_work_center_id.id,
                    'job_issue_line_ids' : [(6, 0, self.tree_ids.job_isse_line_id.ids)],
                    'job_receive_line_ids' : job_receive_line_list,
                })
                if job_receive_id and job_receive_id.job_receive_line_ids:
                    for line in job_receive_id.job_receive_line_ids:
                        if line.tree_management_mo_id:
                            line.tree_management_mo_id.write({
                                'casting_receive_line_id' : line.id,
                                'casting_receive_qty' : line.rec_pcs
                            })
                    job_receive_id.action_confirm()
        return result
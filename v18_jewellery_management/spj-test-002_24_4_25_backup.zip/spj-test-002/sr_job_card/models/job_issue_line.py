
import time
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class JobIssueLine(models.Model):
    _name = 'job.issue.line'
    _inherit = ['mail.thread']
    _description = 'Job Issue Line'
    _rec_name = 'production_id'
    _order = 'id desc'

    job_issue_id = fields.Many2one('job.issue', string="Job Issue", ondelete="cascade")
    production_id = fields.Many2one(
        'mrp.production',
        string='MO/Job No.',
        domain="[('state', '=', 'confirmed')]",
        required=True,
        tracking=True
    )
    product_id = fields.Many2one(string='SKU', related='production_id.product_id', readonly=True, tracking=True)
    metal_id = fields.Many2one(string='Metal', related='product_id.metal', readonly=True, tracking=True)
    colour_id = fields.Many2one(string='Colour', related='product_id.color', readonly=True, tracking=True)
    fineness = fields.Float(string='Fineness', related='product_id.fineness', readonly=True, tracking=True)
    size_id = fields.Many2one(string='Size', related='product_id.size_id', readonly=True, tracking=True)
    order_qty = fields.Float(string='Order QTY', related='production_id.product_qty', readonly=True, tracking=True)
    sc_order_qty = fields.Float(string='Secondary Order QTY', related='production_id.secondary_qty', readonly=True, tracking=True)
    # tree_no = fields.Char(string='Tree No', related='production_id.tree_number', readonly=True, tracking=True)
    tree_id = fields.Many2one(string='Tree No', related='production_id.tree_id', readonly=True, tracking=True)
    workcenter_id = fields.Many2one(related='job_issue_id.workcenter_id', string="Work Center", tracking=True)
    pcs = fields.Float(string="PCS", related='production_id.product_qty', readonly=False, tracking=True)
    issue_gross_weight = fields.Float(string='Gr.Wt', readonly=False, tracking=True)
    issue_net_weight = fields.Float(string='Nt.Wt', readonly=False, tracking=True)
    issue_component_weight = fields.Float(string='Comp.Wt', readonly=False, tracking=True)
    issue_stone_weight = fields.Float(string='Stn.Wt-Gm', readonly=False, tracking=True)
    issue_exact_weight = fields.Float(string='Ext.Wt', readonly=False, tracking=True)
    receive_id = fields.Many2one('job.receive', string='Receive', readonly=True, tracking=True)
    receive_line_id = fields.Many2one('job.receive.line', string='Receive Line', readonly=True, tracking=True)
    state = fields.Selection([('draft', 'Draft'), ('issue', 'Issued'), ('in_progress', 'In Progress'), ('done', 'Done'), ('return', 'Return')], string="Status",
                             default="draft", tracking=True)
    start_time = fields.Datetime('Start Time', store=True, tracking=True)
    end_time = fields.Datetime('End Time', store=True, tracking=True)
    tree_management_mo_id = fields.Many2one("tree.management.mo", string="Tree Line", readonly=False, tracking=True)
    # component_line_id = fields.Many2many("job.issue.component.line", 'component_issue_line_rel',
    #                                      'component_id', 'issue_line_id', string="Component Lines", readonly=False, tracking=True)
    is_show_component = fields.Boolean("Show Component")
    component_ids = fields.One2many('job.issue.line.component.line', 'job_issue_line_id', String="Component",
                                    tracking=True)

    def button_start(self):
        for rec in self:
            rec.write({
                'start_time' : fields.Datetime.now(),
                'state' : 'in_progress',
            })

    def button_done(self):
        for rec in self:
            work_order_ids = self.env['mrp.workorder'].search([('production_id', '=', self.production_id.id), ('workcenter_id', '=', self.workcenter_id.id)])
            if work_order_ids:
                for order in work_order_ids:
                    # order.state = 'done'
                    order.button_finish()
                    order.job_issue_id = rec.job_issue_id.id
            rec.write({
                'end_time': fields.Datetime.now(),
                'state': 'done',
            })

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise ValidationError(
                    f"Sorry, you can only delete records in the draft state.")
        return super(JobIssueLine, self).unlink()

    def action_show_component(self):
        self.ensure_one()
        if not self.component_ids:
            self.onchange_production_id()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Job Issue Line',
            'res_model': 'job.issue.line',
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'current',  # Or 'new' if you want to open in new window
        }

    @api.onchange('production_id')
    def onchange_production_id(self):
        self.component_ids = [(5, 0)]
        if self.production_id:
            workorder_ids = self.env['mrp.workorder'].search([
                ('workcenter_id', '=', self.workcenter_id.id),
                ('production_id.state', 'in', ['confirmed', 'progress']),
                ('production_id', '=', self.production_id.id)
            ])
            print("-----workorder_ids-------",workorder_ids)
            if workorder_ids:
                for workorder in workorder_ids:
                    # print("-----workorder-------", workorder)
                    # print("-----workorder--move_raw_ids-----", workorder.move_raw_ids)
                    for line in workorder.move_raw_ids:
                        print("-----line---22222222222222222----", line)
                        comp_line = self.env['job.issue.line.component.line'].create({
                            'product_id': line.product_id.id,
                            'product_qty': line.product_qty,
                            'location_id': line.location_id.id,
                            'move_id': line.id,
                            'job_issue_line_id': self._origin.id
                        })
                        print("++++++comp_line+++++++", comp_line)
                        # component_list.append((0, 0, {
                        #     'product_id': line.product_id.id,
                        #     'product_qty': line.product_qty,
                        #     'location_id': line.location_id.id,
                        #     'move_id': line.id,
                        #     # 'job_issue_id': self.job_issue_id.id,
                        # }))
                # self.component_ids = component_list

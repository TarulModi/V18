
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class JobReceiveLine(models.Model):
    _name = 'job.receive.line'
    _inherit = ['mail.thread']
    _description = 'Job Receive Line'
    _rec_name = 'job_issue_line_id'
    _order = 'id desc'

    job_receive_id = fields.Many2one('job.receive', string="Job Receive", ondelete="cascade")
    job_issue_line_id = fields.Many2one('job.issue.line', string="Job No", tracking=True, required=True)
    production_id = fields.Many2one(
        related='job_issue_line_id.production_id',
        string='MO/Job No.',
        domain="[('state', '=', 'confirmed')]",
        required=True,
        tracking=True
    )
    product_id = fields.Many2one(string='SKU', related='job_issue_line_id.product_id', readonly=True, tracking=True)
    metal_id = fields.Many2one(string='Metal', related='job_issue_line_id.metal_id', readonly=True, tracking=True)
    colour_id = fields.Many2one(string='Colour', related='job_issue_line_id.colour_id', readonly=True, tracking=True)
    fineness = fields.Float(string='Fineness', related='job_issue_line_id.fineness', readonly=True, tracking=True)
    size_id = fields.Many2one(string='Size', related='job_issue_line_id.size_id', readonly=True, tracking=True)
    # tree_no = fields.Char(string='Tree No', related='job_issue_line_id.tree_no', readonly=True, tracking=True)
    tree_id = fields.Many2one(string='Tree No', related='job_issue_line_id.tree_id', readonly=True, tracking=True)
    workcenter_id = fields.Many2one(related='job_receive_id.workcenter_id', string="Work Center", tracking=True)
    order_qty = fields.Float(string='Order QTY', related='job_issue_line_id.order_qty', readonly=True, tracking=True)
    sc_order_qty = fields.Float(string='Secondary Order QTY', related='job_issue_line_id.sc_order_qty', readonly=True,
                                tracking=True)
    pcs = fields.Float(string="PCS", related='job_issue_line_id.pcs', readonly=True, tracking=True)
    issue_gross_weight = fields.Float(string='Iss Gr.Wt', related='job_issue_line_id.issue_gross_weight', readonly=True, tracking=True)
    issue_net_weight = fields.Float(string='Iss Nt.Wt', related='job_issue_line_id.issue_net_weight', readonly=True, tracking=True)
    issue_component_weight = fields.Float(string='Iss Comp.Wt', related='job_issue_line_id.issue_component_weight', readonly=True, tracking=True)
    issue_stone_weight = fields.Float(string='Iss Stn.Wt-Gm', related='job_issue_line_id.issue_stone_weight', readonly=True, tracking=True)
    issue_exact_weight = fields.Float(string='Iss Ext.Wt', related='job_issue_line_id.issue_exact_weight', readonly=True, tracking=True)

    rec_pcs = fields.Float(string='Ret.Pcs', related='job_issue_line_id.pcs', readonly=False, tracking=True)
    rec_gwt = fields.Float(string='Gr.Wt', related='job_issue_line_id.issue_gross_weight', readonly=False, tracking=True)
    rec_nwt = fields.Float(string='Nt.Wt', related='job_issue_line_id.issue_net_weight', readonly=False, tracking=True)
    component_weight = fields.Float(string='Comp.Wt', related='job_issue_line_id.issue_component_weight', readonly=False, tracking=True)
    scrap = fields.Float(string='Scrap', readonly=False, tracking=True)
    dust = fields.Float(string='Dust', readonly=False, tracking=True)
    loss_wt = fields.Float(string='Loss Wt', readonly=False, tracking=True)
    loss_percentage = fields.Float(string='Loss %', readonly=False, tracking=True)
    awl = fields.Float(string='AWL %', readonly=False, tracking=True)
    tree_management_mo_id = fields.Many2one("tree.management.mo", string="Tree Line", readonly=False, tracking=True)



    # producation_id = fields.Many2one(
    #     'mrp.production',
    #     string='Manufacturing.',
    #     domain="[('state', '=', 'confirmed')]",
    #     required=True,
    #     tracking=True
    # )
    # job_no = fields.Char(string='Job No.', readonly=True, tracking=True)
    # product_id = fields.Many2one('product.product', string='SKU', related='producation_id.product_id', readonly=True, tracking=True)
    # category_id = fields.Many2one('product.category', string='Category', related='producation_id.product_id.categ_id', readonly=True, tracking=True)
    # metal_id = fields.Char(string='Metal', readonly=True, tracking=True)
    # product_color = fields.Char(string='Color', readonly=True, tracking=True)
    # fineness = fields.Float(string='Fineness', readonly=True, tracking=True)
    # size = fields.Char(string='Size', readonly=True, tracking=True)
    # tree_no = fields.Char(string='Tree No', readonly=False, tracking=True)
    # pcs = fields.Float(string='Issue Pcs', readonly=False, tracking=True)
    # uom_id = fields.Many2one('uom.uom', string='Unit', related='producation_id.product_uom_id', readonly=True, tracking=True)
    # issue_gross_weight = fields.Float(string='Iss Gwt', readonly=False, tracking=True)
    # issue_net_weight = fields.Float(string='Iss Nwt', readonly=False, tracking=True)
    #
    # rec_pcs = fields.Float(string='Ret.Pcs', readonly=False, tracking=True)
    # rec_gwt = fields.Float(string='Gwt', readonly=False, tracking=True)
    # rec_nwt = fields.Float(string='Nwt', readonly=False, tracking=True)
    # scrap = fields.Float(string='Scrap', readonly=False, tracking=True)
    # dust = fields.Float(string='Dust', readonly=False, tracking=True)
    # loss_wt = fields.Float(string='Loss Wt', readonly=False, tracking=True)
    # loss_percentage = fields.Float(string='Loss %', readonly=False, tracking=True)
    # awl = fields.Float(string='AWL %', readonly=False, tracking=True)


    # dust_return = fields.Char(string='Dust Rt', readonly=False)
    # allow_loss = fields.Char(string='Awl%', readonly=False)

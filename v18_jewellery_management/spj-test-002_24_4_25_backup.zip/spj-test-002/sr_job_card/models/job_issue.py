
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class JobIssue(models.Model):
    _name = 'job.issue'
    _inherit = ['mail.thread']
    _description = 'Job Issue'
    _rec_name = 'name'
    _order = 'id desc'

    name = fields.Char(string="I/R ID No.", required=True, copy=False, readonly=True, default='New', tracking=True)
    date = fields.Date(string="Date", default=fields.Date.context_today, tracking=True)
    workcenter_id = fields.Many2one('mrp.workcenter', string="Process (Work Center)", tracking=True, copy=False)
    department_id = fields.Many2one('hr.department', string="Department", tracking=True)
    worker_id = fields.Many2one('hr.employee', string="Worker", tracking=True)
    state = fields.Selection([('draft', 'Draft'), ('issue', 'Issued'), ('return', 'Return')], string="Status", default="draft", tracking=True)
    job_issue_line_ids = fields.One2many('job.issue.line', 'job_issue_id', string="Issue Details")
    # job_issue_component_ids = fields.One2many('job.issue.component.line', 'job_issue_id', string="Issue Component Details")
    production_ids = fields.Many2many(
        'mrp.production',
        domain="[('state', '=', 'confirmed')]",
        copy=False
    )
    is_all_return = fields.Boolean("Is all return", compute="check_all_return")
    tree_count = fields.Integer(string="# Tree", compute="_compute_tree_management_count")

    @api.depends('job_issue_line_ids', 'job_issue_line_ids.state', 'is_all_return')
    def check_all_return(self):
        for record in self:
            record.is_all_return = False
            if record.job_issue_line_ids:
                all_in_return = all(line.state == 'return' for line in record.job_issue_line_ids)
                if all_in_return and record.state != 'return':
                    record.state = 'return'

    @api.model
    def create(self, vals):
        if vals.get('name', "New") == "New":
            vals['name'] = self.env['ir.sequence'].next_by_code('job.issue') or "New"
        return super(JobIssue, self).create(vals)

    @api.onchange('workcenter_id')
    def onchange_workcenter_id(self):
        if self.workcenter_id:
            self.job_issue_line_ids = [(5, 0)]
            workorder_ids = self.env['mrp.workorder'].search([
                ('workcenter_id', '=', self.workcenter_id.id),
                ('production_id.state', 'in', ['confirmed','progress']),
                ('state', 'not in', ['done', 'cancel']),
                ('job_issue_id', '=', False)
            ])
            if workorder_ids:
                unique_production_ids = list(set(workorder_ids.mapped('production_id').ids))
                self.production_ids = [(6, 0, unique_production_ids)]
            else:
                self.production_ids = [(6, 0, [])]

    # @api.onchange('job_issue_line_ids')
    # def onchange_job_issue_line_ids(self):
    #     print("-------contexttttttt------------", self.env.context)
    #     print("-------contexttttttt-------get-----", self.env.context.get('component'))
    #     print("-------job_issue_line_ids------------", self.job_issue_line_ids)
    #     print("-------job_issue_line_ids-----production_id-------", self.job_issue_line_ids.production_id)
    #     component_list = []
    #     if self.job_issue_line_ids and self.job_issue_line_ids.production_id:
    #     # if self.job_issue_line_ids and self.job_issue_line_ids.production_id and self.env.context.get('component'):
    #         workorder_ids = self.env['mrp.workorder'].search([
    #             ('workcenter_id', '=', self.workcenter_id.id),
    #             ('production_id.state', 'in', ['confirmed', 'progress']),
    #             ('production_id', 'in', self.job_issue_line_ids.production_id.ids)
    #         ])
    #         print("-----workorder_idsworkorder_idsworkorder_idsworkorder_idsworkorder_ids-----",workorder_ids)
    #         if workorder_ids:
    #             for workorder in workorder_ids:
    #                 job_issue_line_id = self.job_issue_line_ids.filtered(lambda r: r.production_id.id == workorder.production_id.id)
    #                 print("-----job_issue_line_id-------job_issue_line_id-----",job_issue_line_id)
    #                 for line in workorder.move_raw_ids:
    #                     component_list.append((0, 0, {
    #                         'product_id': line.product_id.id,
    #                         'product_qty': line.product_qty,
    #                         'location_id': line.location_id.id,
    #                         'move_id': line.id,
    #                         'job_issue_line_id': job_issue_line_id.id
    #                     }))
    #             print("-------component_list-----222-------",component_list)
    #             self.job_issue_component_ids = [(5, 0, 0)] + component_list

    @api.constrains('job_issue_line_ids')
    def _check_job_issue_line_ids(self):
        machin_list = []
        for record in self:
            for line in record.job_issue_line_ids:
                if line.production_id.id in machin_list:
                    raise ValidationError(f"Sorry, you can't set the same production '{line.production_id.name}' multiple times.")
                else:
                    machin_list.append(line.production_id.id)

    def action_confirm(self):
        self.write({'state': 'issue'})
        self.job_issue_line_ids.write({'state': 'issue'})

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise ValidationError(
                    f"Sorry, you can't delete issue or return records")
        return super(JobIssue, self).unlink()

    @api.depends('job_issue_line_ids.tree_management_mo_id')
    def _compute_tree_management_count(self):
        for record in self:
            if record.job_issue_line_ids and record.job_issue_line_ids.tree_management_mo_id:
                record.tree_count = self.env['tree.management'].search_count(
                    [('id', '=', record.job_issue_line_ids.tree_management_mo_id.tree_management_id.id)])
            else:
                record.tree_count = 0

    def open_tree_management_record(self):
        action = self.env['ir.actions.actions']._for_xml_id('silver_plusss.action_tree_management')
        if self.tree_count >= 1:
            action['domain'] = [('id', '=', self.job_issue_line_ids.tree_management_mo_id.tree_management_id.id)]
        return action

    # def fetch_component_record(self):
    #     print("----------------caaaaaaaallllll-----------")
    #     component_list = []
    #     if self.job_issue_line_ids:
    #         for issue_line in self.job_issue_line_ids:
    #             workorder_ids = self.env['mrp.workorder'].search([
    #                 ('workcenter_id', '=', issue_line.workcenter_id.id),
    #                 ('production_id.state', 'in', ['confirmed', 'progress']),
    #                 ('production_id', 'in', issue_line.production_id.ids)
    #             ])
    #             print("-----workorder_idsworkorder_idsworkorder_idsworkorder_idsworkorder_ids-----",workorder_ids)
    #             if workorder_ids:
    #                 print("-----workorder_idsworkorder_idsworkorder_idsworkorder_idsworkorder_ids----222-----",workorder_ids)
    #                 for workorder in workorder_ids:
    #                     for line in workorder.move_raw_ids:
    #                         component_list.append((0, 0, {
    #                             'product_id': line.product_id.id,
    #                             'product_qty': line.product_qty,
    #                             'location_id': line.location_id.id,
    #                             'move_id': line.id,
    #                             'job_issue_line_id': issue_line.id
    #                         }))
    #                 print("-------component_list-----222-------",component_list)
    #                 # self.job_issue_component_ids = [(5, 0, 0)] + component_list
    #                 self.job_issue_component_ids = [(5, 0, 0)] + component_list
    #                 # if self.job_issue_component_ids:

from odoo import models, fields, api, _


class TreeManagementMO(models.Model):
    _inherit = 'tree.management.mo'
    _order = 'id desc'

    receive_line_id = fields.Many2one('job.receive.line', string="MO/Job No.", order='id desc')

    # Override
    mo_no = fields.Many2one(
        related='receive_line_id.production_id',
        string='MO No.',
        required=True
    )
    product_id = fields.Many2one('product.product', string='SKU', related='receive_line_id.product_id', readonly=True)
    quantity = fields.Float(string='Order Quantity', related='receive_line_id.order_qty', readonly=True)
    return_piece = fields.Float(string='Rtn.Pcs', related='receive_line_id.rec_pcs', readonly=False)
    gross_weight = fields.Float(string='GrossWt', related='receive_line_id.rec_gwt', readonly=False)
    net_weight = fields.Float(string='NetWt', related='receive_line_id.rec_nwt', readonly=False)
    component_weight = fields.Float(string='Component Wt', related='receive_line_id.component_weight', readonly=False)
    unit = fields.Many2one('uom.uom', string='Unit', related='receive_line_id.production_id.product_uom_id', readonly=True)
    job_isse_line_id = fields.Many2one("job.issue.line", string="Job Issue Line")
    job_issue_qty = fields.Float("Job Issue QTY")
    casting_receive_line_id = fields.Many2one('job.receive.line', string="Job Receive", order='id desc')
    casting_receive_qty = fields.Float("Job Receive QTY")

    # Casting Receive details
    cst_rec_pcs = fields.Float("CST RCV PCS")
    cst_gross_weight = fields.Float("CST GRS WT")
    cst_net_weight = fields.Float("CST NT WT")
    scp_spr_cut = fields.Float("Scrap-Spure Cutting")
    loss_spr_cut = fields.Float("Loss-Spure Cutting")
    mt_consumption = fields.Float("Mt Consumption", readonly=1)

    ratio = fields.Float("Ration", readonly=1)
    spure_scrap = fields.Float("Spure Scrap", readonly=1)
    spure_dust = fields.Float("Spure Dust", readonly=1)
    spure_loss = fields.Float("Spure Loss", readonly=1)

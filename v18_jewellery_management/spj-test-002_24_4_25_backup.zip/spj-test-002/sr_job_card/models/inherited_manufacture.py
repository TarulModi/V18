
from odoo import models, fields, _


class mrpProduction(models.Model):
    _inherit = 'mrp.production'
    _order = 'id desc'

    tree_id = fields.Many2one("tree.management", string="Tree No.", copy=False, tracking=True)


class mrpWorkorder(models.Model):
    _inherit = 'mrp.workorder'

    job_issue_id = fields.Many2one("job.issue", string="Job Issue.", copy=False, tracking=True)

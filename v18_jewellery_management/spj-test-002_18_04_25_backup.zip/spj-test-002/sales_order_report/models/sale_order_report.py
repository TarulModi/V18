from odoo import models, fields, api

class SaleOrderReport(models.Model):
    _name = 'sale.order.report'
    _description = 'Sales Order Report'
    _auto = False  # Read-only model

    order_id = fields.Many2one('sale.order', string="Order No", readonly=True)
    customer_id = fields.Many2one('res.partner', string="Customer", readonly=True)
    date_order = fields.Datetime(string="Date", readonly=True)
    product_id = fields.Many2one('product.product', string="Product", readonly=True)
    product_uom_qty = fields.Float(string=" Order Quantity", readonly=True)
    qty_delivered = fields.Float(string="Delivered Quantity", readonly=True)
    remaining_quantity = fields.Float(string="Remaining Quantity", readonly=True)
    gross_weight = fields.Float(string="Gross Weight", readonly=True)
    net_weight = fields.Float(string="Net Weight", readonly=True)
    fineness = fields.Float(string="Fineness", readonly=True)
    fine_weight = fields.Float(string="Fine Weight", readonly=True)
    remark_ids = fields.Char(string="Remark",readonly=True)
    bom_id = fields.Many2one('mrp.bom', string="BOM", readonly=True)
    metal_market_rate = fields.Float(string="Metal Market Rate", readonly=True)
    computed_bom_cost = fields.Float(string="Cost(Mkt)", readonly=True)
    price_unit = fields.Float(string="Unit Price", readonly=True)
    price_subtotal = fields.Float(string="Subtotal", readonly=True)
    product_collection = fields.Many2one('collection.master', string="Collection", readonly=True)
    metal_product = fields.Many2one('metal.master', string="Metal", readonly=True)
    metal_colour = fields.Many2one('colour.master', string="Metal Color", readonly=True)
    product_size = fields.Many2one('size.master', string="Size", readonly=True)
    mo_qty_manufactured = fields.Float(string="Order Released", compute="_compute_manufactured_qty", store=False)
    mo_remaining_qty = fields.Float(string="To Released", compute="_compute_manufactured_qty", store=False)

    def init(self):
        """ Create a SQL view to fetch data dynamically """
        self.env.cr.execute("""
            CREATE OR REPLACE VIEW sale_order_report AS (
                SELECT 
                    sol.id AS id, 
                    so.id AS order_id,
                    so.partner_id AS customer_id,
                    so.date_order AS date_order,
                    sol.product_id AS product_id,
                    sol.product_uom_qty AS product_uom_qty,
                    sol.qty_delivered AS qty_delivered,
                    sol.gross_weight AS gross_weight,
                    sol.net_weight AS net_weight,
                    sol.fineness AS fineness,
                    sol.fine_weight AS fine_weight,
                    sol.remark_ids AS remark_ids,
                    sol.bom_id AS bom_id,
                    sol.metal_market_rate AS metal_market_rate,
                    sol.computed_bom_cost AS computed_bom_cost,
                    sol.price_unit AS price_unit,
                    sol.price_subtotal AS price_subtotal,
                    sol.product_collection AS product_collection,
                    sol.metal_product AS metal_product,
                    sol.metal_colour AS metal_colour,
                    sol.product_size AS product_size,
                    (sol.product_uom_qty - sol.qty_delivered) AS remaining_quantity
                FROM sale_order_line sol
                JOIN sale_order so ON sol.order_id = so.id
                WHERE sol.product_uom_qty > sol.qty_delivered  -- Not fully delivered
                AND so.state NOT IN ('cancel', 'draft', 'sent')  -- Exclude Quotations & Canceled orders
            )
        """)

    @api.depends('order_id', 'product_id')
    def _compute_manufactured_qty(self):
        for rec in self:
            mo_qty = 0.0
            if rec.order_id and rec.product_id:
                mo_list = self.env['mrp.production'].search([
                    ('origin', '=', rec.order_id.name),
                    ('product_id', '=', rec.product_id.id),
                    ('state', 'not in', ['cancel'])  # Only count non-cancelled MOs
                ])
                mo_qty = sum(mo.product_qty for mo in mo_list)
            rec.mo_qty_manufactured = mo_qty
            rec.mo_remaining_qty = rec.remaining_quantity - mo_qty



from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ProductGoldWaxRatio(models.Model):
    _name = 'product.gold.wax.ratio'
    _description = 'Product Gold Wax Ratio'

    product_id = fields.Many2one('product.template', string='Product', required=True, ondelete='cascade')
    product_name = fields.Char(string='Product Name', compute='_compute_product_name', store=True)
    wax_ratio = fields.Float(string='Wax')
    gold_ratio = fields.Float(string='Gold')
    ratio = fields.Float(string='Ratio',compute='_compute_ratio',store=True)

    @api.depends('product_id')
    def _compute_product_name(self):
        for record in self:
            record.product_name = record.product_id.name

    @api.depends('wax_ratio', 'gold_ratio')
    def _compute_ratio(self):
        for record in self:
            if record.gold_ratio != 0:
                record.ratio = record.gold_ratio / record.wax_ratio
            else:
                record.ratio = 0
class ProductTemplate(models.Model):
    _inherit = 'product.template'

    gold_wax_ratio_ids = fields.One2many('product.gold.wax.ratio', 'product_id', string='Gold Wax Ratios')

    @api.constrains('gold_wax_ratio_ids')
    def _check_single_line(self):
        for record in self:
            if len(record.gold_wax_ratio_ids) > 1:
                raise ValidationError('You can only add one gold wax ratio per product.')
{
    'name': 'Route Template',
    'version': '1.0',
    'summary': 'Module to manage route templates with work orders',
    'author': 'Gaurav Goswami',
    'depends': ['mrp'],
    'data': [
        'security/ir.model.access.csv',
        'views/route_template_views.xml',
        'views/mrp_production_views.xml',
    ],
    'installable': True,
    'application': False,
}

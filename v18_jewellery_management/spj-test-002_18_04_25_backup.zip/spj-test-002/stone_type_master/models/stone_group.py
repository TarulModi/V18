from odoo import models, fields, api

class StoneTypeMaster(models.Model):
    _name = "stone.group"
    _description = "Stone Group"
    _rec_name = "stone_group"

    stone_group = fields.Char(string="Stone Group Name", required=True)
    stone_group_code = fields.Char(string="Stone Group Code", required=True, unique=True)
    stone_group_description = fields.Char(string="Stone Category")
    created_date = fields.Datetime(string="Created Date", default=fields.Datetime.now, readonly=True)
    last_modified_date = fields.Datetime(string="Last Modified Date", default=fields.Datetime.now)

    @api.model
    def create(self, vals):
        vals['created_date'] = fields.Datetime.now()
        vals['last_modified_date'] = fields.Datetime.now()
        return super(StoneTypeMaster, self).create(vals)

    def write(self, vals):
        vals['last_modified_date'] = fields.Datetime.now()
        return super(StoneTypeMaster, self).write(vals)

from odoo import models, fields, api
from odoo.exceptions import UserError


class Consignment(models.Model):
    _name = 'consignment'
    _description = 'Consignment'
    _rec_name = 'name'

    name = fields.Char(string='Consignment No.', copy=False, readonly=True)

    vendor_id = fields.Many2one('res.partner', string='Vendor', required=True)
    contact_person = fields.Char(string='Contact Person')
    contact_no = fields.Char(string='Contact No.')
    vendor_reference = fields.Char(string='Vendor Reference')
    date_creation = fields.Datetime(string='Date of Creation', default=fields.Datetime.now)
    state = fields.Selection([
        ('created', 'Created'),
        ('received', 'Received'),
        ('return', 'Return')
    ], string='Status', default='created')
    purchase_order_references = fields.Text(string="Purchase Order References", readonly=True)

    consignment_line_ids = fields.One2many('consignment.line', 'consignment_id', string='Consignment Lines')
    consignment_sorting_ids = fields.One2many('consignment.sorting', 'consignment_id', string="Sorting Records")

    @api.model
    def create(self, vals):
        if not vals.get('name'):  # Ensure name is not manually provided
            vals['name'] = self.env['ir.sequence'].next_by_code('consignment') or 'New'
        res = super(Consignment, self).create(vals)

        # Assign serial numbers to consignment lines
        sl_no = 0
        for line in res.consignment_line_ids:
            sl_no += 1
            line.sl_no = sl_no

        return res

    def write(self, values):
        res = super(Consignment, self).write(values)

        # Reassign serial numbers in case of updates
        sl_no = 0
        for line in self.consignment_line_ids:
            sl_no += 1
            line.sl_no = sl_no

        return res

    def action_set_created(self):
        self.state = 'created'

    def action_set_received(self):
        self.state = 'received'

    def action_set_return(self):
        self.state = 'return'

        for line in self.consignment_line_ids:
            # Move balance to return fields
            line.return_qty = line.balance_qty
            line.return_pcs = line.balance_pcs

            # Set balance to zero
            line.balance_qty = 0
            line.balance_pcs = 0

    def action_create_purchase_orders(self):
        """ Create a separate Purchase Order for each Consignment Line with sorted products. """
        PurchaseOrder = self.env['purchase.order']
        PurchaseOrderLine = self.env['purchase.order.line']

        for consignment in self:
            po_references = []  # Reset for each consignment

            for consignment_line in consignment.consignment_line_ids:
                # Skip if sorting is not checked
                if not consignment_line.sorting:
                    continue

                # Skip if a PO is already created
                if consignment_line.reference_po:
                    po_references.append(consignment_line.reference_po)
                    continue

                # Create a new Purchase Order
                purchase_order = PurchaseOrder.create({
                    'partner_id': consignment.vendor_id.id,
                    'origin': consignment.name,
                    'date_order': fields.Datetime.now(),
                })

                # Find all Sorting Lines linked to this Consignment Line
                sorting_lines = self.env['consignment.sorting.line'].search([
                    ('sorting_id.consignment_line_id', '=', consignment_line.id)
                ])

                if not sorting_lines:
                    raise UserError(f"No sorting lines found for Consignment Line {consignment_line.id}.")

                for sorting_line in sorting_lines:
                    # Ensure product is selected
                    if not sorting_line.product_id:
                        raise UserError(f"Product is missing in sorting line {sorting_line.id}.")

                    # Create Purchase Order Line
                    PurchaseOrderLine.create({
                        'order_id': purchase_order.id,
                        'product_id': sorting_line.product_id.id,
                        'name': sorting_line.product_id.name,
                        'product_qty': sorting_line.qty_weight,  # Sorted quantity
                        'product_uom': sorting_line.primary_uom.id,
                        'price_unit': sorting_line.product_id.standard_price,
                        'date_planned': fields.Datetime.now(),
                    })

                # Store the PO reference in the Consignment Line
                consignment_line.reference_po = purchase_order.name
                po_references.append(purchase_order.name)  # Append newly created PO

            # Store all PO references as a comma-separated string
            consignment.purchase_order_references = ", ".join(po_references) if po_references else ""

        return True


class ConsignmentLine(models.Model):
    _name = 'consignment.line'
    _description = 'Consignment Line'

    consignment_id = fields.Many2one('consignment', string='Consignment', required=True, ondelete='cascade')
    sl_no = fields.Integer(string='S.No.')
    product_id = fields.Many2one(
        'product.template',
        string='Product',
        required=True,
    )
    # product_description = fields.Char(string='Product Description')
    qty_weight = fields.Float(string='Quantity in Weight')
    qty_pcs = fields.Float(string='Quantity in Pcs')
    primary_uom = fields.Many2one('uom.uom', string='Primary UOM', related='product_id.uom_id', readonly=True)
    secondary_uom = fields.Many2one('uom.uom', string='Secondary UOM')
    sorting = fields.Boolean(string='Sorted')

    sum_sorted_qty = fields.Float(
        string='Sum of Sorted Pcs', compute='_compute_sorted_values', store=True
    )
    sum_sorted_weight = fields.Float(
        string='Sum of Sorted WT', compute='_compute_sorted_values', store=True
    )

    return_qty = fields.Float(string='Return WT')
    return_pcs = fields.Float(string='Return Pcs')
    balance_qty = fields.Float(string='Balance WT', compute='_compute_balance_qty', store=True)
    balance_pcs = fields.Float(string='Balance Pcs', compute='_compute_balance_pcs', store=True)
    reference_po = fields.Char(string="Reference Purchase Order")  # Ensured this field exists in DB

    def action_open_sorting(self):
        """ Open Sorting Form for the selected Consignment Line. If already sorted, open existing record. """
        if not self.consignment_id:
            raise UserError("No consignment linked to this line. Please check!")

        # Searching by consignment_line_id instead of consignment_id
        existing_sorting = self.env['consignment.sorting'].search([
            ('consignment_line_id', '=', self.id)
        ], limit=1)

        if not existing_sorting:
            existing_sorting = self.env['consignment.sorting'].create({
                'consignment_id': self.consignment_id.id,
                'consignment_line_id': self.id,  # Link to this specific consignment line
                'worker_id': self.env.user.id,
                'date': fields.Datetime.now(),
            })

        return {
            'name': 'Sorting',
            'type': 'ir.actions.act_window',
            'res_model': 'consignment.sorting',
            'view_mode': 'form',
            'res_id': existing_sorting.id,
            'target': 'new'
        }

    @api.depends('consignment_id.consignment_sorting_ids.sorting_line_ids.qty_pcs',
                 'consignment_id.consignment_sorting_ids.sorting_line_ids.qty_weight')
    def _compute_sorted_values(self):
        """ Compute sorted values (qty and weight) from sorting lines """
        for line in self:
            sorting_lines = self.env['consignment.sorting.line'].search([
                ('sorting_id.consignment_line_id', '=', line.id),
                # ('product_id', '=', line.product_id.id)
            ])
            line.sum_sorted_qty = sum(sorting_lines.mapped('qty_pcs')) or 0
            line.sum_sorted_weight = sum(sorting_lines.mapped('qty_weight')) or 0

    @api.depends('qty_weight', 'sum_sorted_weight')
    def _compute_balance_qty(self):
        """ Compute balance_qty as qty_weight - sum_sorted_weight """
        for line in self:
            line.balance_qty = line.qty_weight - line.sum_sorted_weight

    @api.depends('qty_pcs', 'sum_sorted_qty')
    def _compute_balance_pcs(self):
        """ Compute balance_qty as qty_pcs - sum_sorted_qty """
        for line in self:
            line.balance_pcs = line.qty_pcs - line.sum_sorted_qty

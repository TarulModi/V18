from odoo import models, fields, api
from odoo.exceptions import UserError

class IssueReceive(models.Model):
    _name = 'issue.receive'
    _description = 'Issue Receive'

    name = fields.Char(string="I/R ID No.", required=True, copy=False, readonly=True, default='New')
    type = fields.Selection([('issue', 'Issue'), ('receive', 'Receive')], string="Type", required=True)
    date = fields.Date(string="Date", default=fields.Date.context_today)
    process_id = fields.Many2one('mrp.workcenter', string="Process (Operation)")
    department_id = fields.Many2one('hr.department', string="Department")
    worker_id = fields.Many2one('hr.employee', string="Worker")
    state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirm')], string="Status", default="draft")
    line_ids = fields.One2many('issue.receive.line', 'issue_receive_id', string="Issue Receive Lines")

    component_line_ids = fields.One2many('issue.receive.component.line', 'issue_receive_id', string="Components")

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            prefix = 'ISU' if vals.get('type') == 'issue' else 'RCV'
            vals['name'] = self.env['ir.sequence'].next_by_code('issue.receive.%s' % vals['type']) or f"{prefix}001"
        return super(IssueReceive, self).create(vals)

    def action_confirm(self):
        """ Set the state to 'Confirm' when the Confirm button is clicked """
        self.write({'state': 'confirm'})

    # need refinement in below code(action_fetch_components)
    def action_fetch_components(self):
        """ Fetch components from the selected Manufacturing Order and update component lines accordingly """
        for record in self:
            selected_mo_ids = record.line_ids.filtered(lambda l: l.select_mo and l.mo_no)

            # Validation: Only one MO should be selected at a time
            if len(selected_mo_ids) > 1:
                raise UserError("You can select only one Manufacturing Order at a time.")

            # Clear existing component lines if no MO is selected
            if not selected_mo_ids:
                record.component_line_ids.unlink()
                return

            selected_mo = selected_mo_ids[0].mo_no  # Get the selected MO

            # Keep track of existing component lines
            existing_components = {comp.product_id.id: comp for comp in record.component_line_ids}

            new_components = []
            for component in selected_mo.move_raw_ids:  # Fetch raw materials from MO
                if component.product_id.id in existing_components:
                    # If component already exists, update its quantity
                    existing_components[component.product_id.id].product_qty = component.product_uom_qty
                else:
                    new_components.append((0, 0, {
                        'product_id': component.product_id.id,
                        'product_qty': component.product_uom_qty,
                        'unit': component.product_uom.id,
                        'source_location_id': component.location_id.id,
                    }))

            # Update component lines with new data
            record.component_line_ids = new_components

    def action_add_components_to_mo(self):
        """ Add new components to MO and update modified ones """
        for record in self:
            selected_mo_lines = record.line_ids.filtered(lambda l: l.select_mo and l.mo_no)

            if not selected_mo_lines:
                raise UserError("Please select at least one Manufacturing Order.")

            for mo_line in selected_mo_lines:
                mo = mo_line.mo_no  # Selected Manufacturing Order

                # Get existing components in the MO
                existing_mo_components = {move.product_id.id: move for move in mo.move_raw_ids}

                for component in record.component_line_ids:
                    if component.product_id.id in existing_mo_components:
                        # Update existing component quantity in the MO
                        existing_mo_components[component.product_id.id].write({
                            'product_uom_qty': component.product_qty,

                            'location_id': component.source_location_id.id  # ✅ Corrected
                        })
                    else:
                        # Add only the new manually added component
                        self.env['stock.move'].create({
                            'name': f'Component: {component.product_id.display_name}',
                            'product_id': component.product_id.id,
                            'product_uom_qty': component.product_qty,
                            'product_uom': component.unit.id,
                            'location_id': component.source_location_id.id,
                            'location_dest_id': mo.location_dest_id.id,  # MO's destination location
                            'raw_material_production_id': mo.id,  # Link to MO
                            'state': 'confirmed',  # Mark as confirmed
                        })


class IssueReceiveLine(models.Model):
    _name = 'issue.receive.line'
    _description = 'Issue Receive Line'

    issue_receive_id = fields.Many2one('issue.receive', string="Issue Receive", ondelete="cascade")
    select_mo = fields.Boolean(string='Select', default=False)
    mo_no = fields.Many2one(
        'mrp.production',
        string='Mo. No.',
        domain="[('state', '=', 'confirmed')]",
        required=True
    )
    job_no_id = fields.Char(string='Job No.', readonly=True)

    product_id = fields.Many2one('product.product', string='SKU', related='mo_no.product_id', readonly=True)
    category_id = fields.Many2one('product.category', string='Item', related='mo_no.product_id.categ_id', readonly=True)
    metal_id = fields.Char(string='Metal', readonly=True)
    product_color = fields.Char(string='Color', readonly=True)
    fineness = fields.Float(string='Fineness', readonly=True)
    size_id = fields.Char(string='Size', readonly=True)
    unit = fields.Many2one('uom.uom', string='Unit', related='mo_no.product_uom_id', readonly=True)
    tree_no_id = fields.Char(string='Tree No', readonly=False)
    pieces = fields.Char(string='Pcs', readonly=False)
    issue_gross_weight = fields.Char(string='Iss Gwt', readonly=False)
    issue_Net_weight = fields.Char(string='Iss Nwt', readonly=False)
    return_weight = fields.Char(string='Ret.Pcs', readonly=False)
    gross_weight = fields.Char(string='Gwt', readonly=False)
    net_weight = fields.Char(string='Nwt', readonly=False)
    scrap = fields.Char(string='Scrap', readonly=False)
    dust = fields.Char(string='Dust', readonly=False)
    dust_return = fields.Char(string='Dust Rt', readonly=False)
    loss_percentage = fields.Char(string='Loss %', readonly=False)
    Loss_weight = fields.Char(string='Loss Wt', readonly=False)
    allow_loss = fields.Char(string='Awl%', readonly=False)


class IssueReceiveComponentLine(models.Model):
    _name = 'issue.receive.component.line'
    _description = 'Issue Receive Component Line'

    issue_receive_id = fields.Many2one('issue.receive', string="Issue Receive", ondelete="cascade")
    product_id = fields.Many2one('product.product', string="Component")
    product_qty = fields.Float(string="Quantity")
    unit = fields.Many2one('uom.uom', string="Unit")
    source_location_id = fields.Many2one('stock.location', string="Source Location")

from odoo import models, fields, api

class MarketPriceMaster(models.Model):
    _name = 'market.price.master'
    _description = 'Market Price Master'

    product_id = fields.Many2one(
        'product.template',
        string="Product",
        domain=[('is_market_product', '=', True)],
        required=True
    )
    date = fields.Date(string="Date", required=True, default=fields.Date.today)
    market_price = fields.Float(string="Market Price", required=True)

    @api.model
    def create(self, vals):
        """When a new price is created, update the product's market_price."""
        record = super(MarketPriceMaster, self).create(vals)
        record.product_id.market_price = record.market_price
        return record

    def write(self, vals):
        """When the market price is updated, update the product's market_price."""
        result = super(MarketPriceMaster, self).write(vals)
        for record in self:
            if 'market_price' in vals:
                record.product_id.market_price = record.market_price
        return result

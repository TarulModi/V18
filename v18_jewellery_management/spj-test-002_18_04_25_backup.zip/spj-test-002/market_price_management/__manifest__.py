{
    'name': "Market Price Management",
    'version': '1.0',
    'depends': ['base', 'sale', 'mrp'],
    'author': "Gaurav Goswami",
    'category': 'Product',
    'summary': "Manage market prices for selected products.",
    'data': [
        'security/ir.model.access.csv',
        'views/product_template_views.xml',
        'views/market_price_master_views.xml',
        'views/sale_order_line_views.xml',
        'views/bom_overview_views.xml',
    ],
    'installable': True,
    'application': True,
}

# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import models, fields, api


class ChangeProductionQty(models.TransientModel):
    _inherit = 'change.production.qty'

    def change_prod_qty(self):
        result = super(ChangeProductionQty, self).change_prod_qty()
        print("-------mo_id----",self.mo_id)
        print("-------mo_id----",self.product_qty)
        if self.mo_id and self.mo_id.bom_id:
            self.mo_id.secondary_qty = self.mo_id.bom_id.secondary_qty * self.product_qty
        if self.mo_id and self.mo_id.move_raw_ids:
            for line in self.mo_id.move_raw_ids:
                if line.bom_line_id:
                    line.secondary_qty = line.bom_line_id.secondary_qty * self.product_qty

        return result

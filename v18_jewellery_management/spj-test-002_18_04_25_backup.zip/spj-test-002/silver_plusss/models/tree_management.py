from odoo import models, fields, api, _
from odoo.exceptions import UserError


class TreeManagement(models.Model):
    _name = 'tree.management'
    _description = 'Tree Management'
    _rec_name = 'tree_no'

    tree_no = fields.Char(string='Tree No.', readonly=True, copy=False, default='New')
    date_of_tree_creation = fields.Date(string='Date of Tree Creation', default=fields.Date.today)
    tree_weight_wax = fields.Float(string='Tree Weight (Wax)', required=True)
    total_wax_pcs_in_tree = fields.Float(string='Total Wax Pcs in Tree', required=True)
    operation = fields.Char(string='Operation')
    gold_weight = fields.Float(string='Total Casting Return Weight', compute="_compute_gold_weight",
                               inverse="_set_gold_weight", store=True)
    sprue_weight = fields.Float(string='Sprue Weight')
    # total_casting_return_pcs = fields.Float(string='Total Casting Return Pcs')
    extra_weight = fields.Float(string='Extra Weight')
    image = fields.Image(string='Image', compute="_compute_image", store=True,
                         options="{'zoom': true}")  # Change to computed field
    gravity = fields.Float(string='Gravity', compute="_compute_gravity", store=True)
    meta_item = fields.Many2one('product.product', string='Metal/Item', required=False)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('issue_to_casting', 'Tree Issue to Casting'),  # New state added here
        ('casting_done', 'Casting Done'),  # New state added here
        ('confirmed', 'Confirm'),
        ('material_issue', 'Material Requisition'),
    ], string='Status', default='draft', readonly=True)
    work_center = fields.Many2one('mrp.workcenter', string='Work Center')

    required_weight = fields.Float(string='Required Weight', compute="_compute_required_weight", store=True)
    total_required_weight = fields.Float(string='Total Required Weight', compute="_compute_total_required_weight",
                                         store=True)

    total_return_piece = fields.Float(string='Total Casting Return Pcs', compute='_compute_total_return_piece',
                                      store=True)
    tree_ids = fields.One2many('tree.management.mo', 'tree_management_id', string='Tree Lines')
    mo_id = fields.Many2one('mrp.production', string='MO')
    worker = fields.Many2one('res.users', string='Responsible Casting')
    from_location_id = fields.Many2one('stock.location', string='From Location', required=True,
                                       domain="[('usage', '=', 'internal')]")
    to_location_id = fields.Many2one('stock.location', string='To Location', required=True,
                                     domain="[('usage', '=', 'internal')]")

    # ----------------------- start-------------------------
    stock_picking_id = fields.Many2one('stock.picking')
    metal_tree_weight = fields.Float("Metal Tree Weight")
    scrap_casting_weight = fields.Float("Scrap(Casting) Weight", digit=(16, 3))
    loss_casting = fields.Float("Loss Casting", digit=(16, 3))

    # ---------------------end-----------------------------

    @api.model
    def create(self, vals):
        if not vals.get('tree_no'):
            vals['tree_no'] = self.env['ir.sequence'].next_by_code('tree.management.tree_no')
        res = super(TreeManagement, self).create(vals)

        sl_no = 0
        for line in res.tree_ids:
            sl_no += 1
            line.sl_no = sl_no

        # ----------------start-------------
        if res and res.tree_ids:
            total_retuen_pcs = sum(res.tree_ids.mapped('return_piece'))
            print("----total_retuen_pcs-----------", total_retuen_pcs)
            res.total_wax_pcs_in_tree = total_retuen_pcs
        # ---------------------END-----------------
        return res

    def write(self, values):
        res = super(TreeManagement, self).write(values)

        sl_no = 0
        for line in self.tree_ids:
            sl_no += 1
            line.sl_no = sl_no

        # ----------------start-------------
        print("-------values----values-----------", values)
        if self.tree_ids and 'tree_ids' in values:
            total_retuen_pcs = sum(self.tree_ids.mapped('return_piece'))
            print("----total_retuen_pcs-----------", total_retuen_pcs)
            self.total_wax_pcs_in_tree = total_retuen_pcs

        if 'metal_tree_weight' in values or 'moid' in values:
            self.mo_id.product_qty = self.metal_tree_weight
        # ---------------------END-----------------
        return res

    def unlink(self):
        for record in self:
            mo_ids = record.tree_ids.mapped('mo_no')
            for mo in mo_ids:
                mo.tree_number = False
        return super(TreeManagement, self).unlink()

    @api.depends('tree_weight_wax', 'meta_item')
    def _compute_required_weight(self):
        for record in self:
            if record.meta_item and record.meta_item.gold_wax_ratio_ids:
                ratio = record.meta_item.gold_wax_ratio_ids[0].ratio
                record.required_weight = record.tree_weight_wax * ratio
            else:
                record.required_weight = 0

    @api.depends('tree_ids.return_piece')
    def _compute_total_return_piece(self):
        for record in self:
            record.total_return_piece = sum(record.tree_ids.mapped('return_piece'))

    def action_issue_to_casting(self):
        for record in self:
            record.state = 'issue_to_casting'

    # --------------------- start--------------------
    def action_material_issue(self):
        for record in self:
            if record.meta_item:
                mo = self.env['mrp.production'].create({
                    'product_id': record.meta_item.id,
                    'product_qty': 1,
                    'product_uom_id': record.meta_item.uom_id.id if record.meta_item.uom_id else None,
                    'bom_id': record.meta_item.bom_ids[:1].id if record.meta_item.bom_ids else None,
                    'origin': record.tree_no,
                    'location_src_id': record.to_location_id.id,
                })
                for move in mo.move_raw_ids:
                    move.product_uom_qty = record.total_required_weight
                record.mo_id = mo.id
                record.mo_id.product_qty = record.metal_tree_weight
                record.state = 'material_issue'

                # Create a transfer order (Stock Picking) to move components
                picking_type = self.env['stock.picking.type'].search([
                    ('code', '=', 'internal'),
                    ('warehouse_id', '=', record.from_location_id.warehouse_id.id)
                ], limit=1)

                if picking_type:
                    picking = self.env['stock.picking'].create({
                        'picking_type_id': picking_type.id,
                        'location_id': record.from_location_id.id,  # Source is TO location
                        'location_dest_id': record.to_location_id.id,  # Destination is FROM location
                        'origin': record.tree_no,
                        'move_ids': [(0, 0, {
                            'name': f"Component Transfer for {record.tree_no}",
                            'product_id': component.product_id.id,
                            'product_uom_qty': record.total_required_weight,
                            'product_uom': component.product_uom_id.id,
                            'location_id': record.from_location_id.id,  # Source
                            'location_dest_id': record.to_location_id.id  # Destination
                        }) for component in mo.bom_id.bom_line_ids]
                    })
                    if picking:
                        picking.action_confirm()
                        picking.action_assign()
                        record.stock_picking_id = picking.id
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'CASTING MO Successfully Created',
                    'type': 'rainbow_man',
                }
            }

    # @api.onchange('metal_tree_weight')
    # def onchange_metal_tree_weight_id(self):
    #     if self.mo_id:
    #         print("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr", self.mo_id)
            # self.mo_id.product_qty = self.metal_tree_weight

    # -------------------- end-----------------------

    @api.depends('tree_ids.select_image', 'tree_ids.product_id')
    def _compute_image(self):
        for record in self:
            # Get all selected lines where select_image is True
            selected_lines = record.tree_ids.filtered('select_image')

            # Check if there are any selected lines
            if selected_lines:
                # Get the most recently checked line (the last one in the filtered list)
                latest_checked_line = selected_lines[-1]

                # If the product has an image, set it as the record's image
                if latest_checked_line.product_id and latest_checked_line.product_id.image_1920:
                    record.image = latest_checked_line.product_id.image_1920
                else:
                    record.image = False
            else:
                # If no lines are selected, clear the image
                record.image = False

    @api.depends('tree_ids.net_weight')
    def _compute_gold_weight(self):
        for record in self:
            record.gold_weight = sum(record.tree_ids.mapped('net_weight'))

    def _set_gold_weight(self):
        pass

    @api.depends('required_weight', 'extra_weight')
    def _compute_total_required_weight(self):
        for record in self:
            record.total_required_weight = record.required_weight + record.extra_weight

    @api.depends('meta_item')
    def _compute_gravity(self):
        for record in self:
            if record.meta_item and record.meta_item.gold_wax_ratio_ids:
                record.gravity = record.meta_item.gold_wax_ratio_ids[0].ratio
            else:
                record.gravity = 0

    def action_confirm(self):
        for record in self:
            record.state = 'confirmed'
            # if record.mo_id:  # Check if a Manufacturing Order exists
            #     record.mo_id.write({'product_qty': record.gold_weight})  # Update quantity
            #     for move in record.mo_id.move_raw_ids:
            #         move.product_uom_qty = record.total_required_weight  # Update component quantity if needed

    def open_manufacture_order(self):
        self.ensure_one()
        if self.mo_id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Manufacturing Order',
                'view_mode': 'form',
                'res_model': 'mrp.production',
                'res_id': self.mo_id.id,
                'target': 'current',
            }

    def open_internal_transfer(self):
        self.ensure_one()
        if self.stock_picking_id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Internal_transfer',
                'view_mode': 'form',
                'res_model': 'stock.picking',
                'res_id': self.stock_picking_id.id,
                'target': 'current',
            }

    def action_reset(self):
        for record in self:
            if record.mo_id:
                record.mo_id.action_cancel()
                record.mo_id.unlink()
                record.mo_id = False
                record.state = 'draft'

                # # Find and delete the related stock picking (transfer)
                # picking = self.env['stock.picking'].search([('origin', '=', record.tree_no)])  # Use the correct field
                #
                # if picking:
                #     picking.action_cancel()  # Cancel the transfer before deleting
                #     picking.unlink()
                #
                # record.state = 'draft'

    def action_casting_done(self):
        for record in self:
            record.state = 'casting_done'

    def action_sprue_cutting(self):
        """Create MOs for pending lines and notify if an MO already exists for some lines."""
        mrp_production = self.env['mrp.production']
        existing_mo_lines = []  # Store line numbers where MO already exists
        new_mo_created = False  # Track if at least one MO is created

        for line in self.env['tree.management.mo'].search([('tree_management_id', '=', self.id)]):
            if line.mo_sprue_cut:
                existing_mo_lines.append(str(line.sl_no))
                continue  # Skip MO creation for this line

            if not line.casting_item or line.return_piece <= 0:
                raise UserError(_('Casting Item is missing or Return Piece is zero for line %s.') % line.sl_no)

            # Create the Manufacturing Order
            mo_vals = {
                'product_id': line.casting_item.id,
                'product_qty': line.return_piece,
                'product_uom_id': line.unit.id,
                'origin': self.tree_no,
                'tree_number': self.tree_no,  # Ensure tree_no is referenced
                'job_no': line.job_no_id,
            }
            mo = mrp_production.create(mo_vals)

            # Link the newly created MO to the line
            line.mo_sprue_cut = mo.id
            new_mo_created = True

        # Show notification if some MOs were already created
        if existing_mo_lines:
            message = _("MO is already created for lines: %s") % ", ".join(existing_mo_lines)
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _("Warning"),
                    'message': message,
                    'sticky': False,
                    'type': 'warning',
                }
            }

        if new_mo_created:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _("Success"),
                    'message': _('Manufacturing Orders created successfully!'),
                    'sticky': False,
                    'type': 'success',
                }
            }

        return True


class TreeManagementMO(models.Model):
    _name = 'tree.management.mo'
    _description = 'Tree Management MO'

    tree_management_id = fields.Many2one('tree.management', string='Tree Management', required=True, ondelete='cascade')
    sl_no = fields.Integer(string='S.No.')

    mo_no = fields.Many2one(
        'mrp.production',
        string='MO No.',
        required=True
    )
    product_id = fields.Many2one('product.product', string='SKU', related='mo_no.product_id', readonly=True)
    category_id = fields.Many2one('product.category', string='Item', related='mo_no.product_id.categ_id',
                                  readonly=True)
    # related = 'mo_no.product_id.metal'
    metal_id = fields.Char(string='Metal', readonly=True)
    job_no_id = fields.Char(string='Job No.', related='mo_no.job_no', readonly=True)
    # related = 'mo_no.product_id.fineness',
    product_color = fields.Char(string='Color', readonly=True)
    # related = 'mo_no.product_id.fineness',
    fineness = fields.Float(string='Fineness', readonly=True)
    # related = 'mo_no.product_id.size',
    size_id = fields.Char(string='Size', readonly=True)
    quantity = fields.Float(string='Order Quantity', related='mo_no.product_qty', readonly=True)
    unit = fields.Many2one('uom.uom', string='Unit', related='mo_no.product_uom_id', readonly=True)
    mo_tree_no = fields.Char(string='Tree NO', related='mo_no.tree_number', readonly=True)
    issue_gross_weight = fields.Float(string='Iss.GWt')
    issue_net_weight = fields.Float(string='Iss.NWt')
    return_piece = fields.Float(string='Rtn.Pcs')
    gross_weight = fields.Float(string='GrossWt')
    net_weight = fields.Float(string='NetWt')
    component_weight = fields.Float(string='Component Wt')
    reject_piece = fields.Float(string='Rej Pcs')
    reject_weight = fields.Float(string='Rej Wt')
    reorder_piece = fields.Float(string='Reorder Pcs')
    loss_percentage = fields.Float(string='Loss %')
    loss_weight = fields.Float(string='Loss Wt')
    fine_weight = fields.Float(string='Fine Wt')
    select_image = fields.Boolean(string=' ', default=False)
    operation_id = fields.Many2one('mrp.routing.workcenter', string='Operation', compute='_compute_operation',
                                   store=True)
    mo_ids = fields.Many2many('mrp.production', compute='_compute_mo_ids', store=False)
    casting_item = fields.Many2one('product.product', string='Casting WIP Item')
    mo_sprue_cut = fields.Many2one('mrp.production', string='Sprue Cutting MO', readonly=True)  # Track the created MO
    image_1920 = fields.Image(related="product_id.image_1920")

    @api.depends('tree_management_id.work_center', 'mo_no')
    def _compute_operation(self):
        for record in self:
            work_center = record.tree_management_id.work_center
            mo = record.mo_no
            if work_center and mo:
                # Find the Work Order for this MO that is in the selected Work Center
                work_order = self.env['mrp.workorder'].search([
                    ('workcenter_id', '=', work_center.id),
                    ('production_id', '=', mo.id),
                    ('state', 'not in', ['done', 'cancel'])
                ], limit=1)

                # Set the Operation based on the Work Order
                record.operation_id = work_order.operation_id if work_order else False
            else:
                record.operation_id = False

    @api.depends('tree_management_id.work_center')
    def _compute_mo_ids(self):
        for record in self:
            work_center = record.tree_management_id.work_center
            if work_center:
                # Find Work Orders that:
                # - Belong to the selected Work Center
                # - Are NOT in "done" or "cancel" state
                work_orders = self.env['mrp.workorder'].search([
                    ('workcenter_id', '=', work_center.id),
                    ('state', 'not in', ['done', 'cancel'])
                ])

                # Get related MOs that:
                # - Have Work Orders in this Work Center
                # - Have an operation in the selected Work Center
                # - Are NOT in "done" or "cancel" state
                production_ids = work_orders.mapped('production_id').filtered(lambda mo: any(
                    wo.operation_id.workcenter_id == work_center and wo.state not in ['done', 'cancel']
                    for wo in mo.workorder_ids
                ) and mo.state not in ['done', 'cancel']).ids

                record.mo_ids = production_ids
            else:
                record.mo_ids = []

    @api.onchange('select_image', 'product_id')
    def _onchange_select_image(self):
        for record in self:
            if record.select_image and record.product_id and not record.product_id.image_1920:
                return {
                    'warning': {
                        'title': "Warning",
                        'message': "No photo available for the selected Product.",
                        'type': 'notification'
                    }
                }

    @api.model
    def create(self, vals):
        record = super(TreeManagementMO, self).create(vals)
        if record.tree_management_id and record.mo_no:
            record.mo_no.tree_number = record.tree_management_id.tree_no
        return record

    def write(self, vals):
        for record in self:
            if 'mo_no' in vals:
                if record.mo_no:
                    record.mo_no.tree_number = False
                new_mo = self.env['mrp.production'].browse(vals['mo_no'])
                if new_mo and record.tree_management_id:
                    new_mo.tree_number = record.tree_management_id.tree_no
        return super(TreeManagementMO, self).write(vals)

    def unlink(self):
        for record in self:
            if record.mo_no:
                record.mo_no.tree_number = False
        return super(TreeManagementMO, self).unlink()

# @api.depends('select_image')
# def _compute_exclusive_checkbox(self):
#     for record in self:
#         if record.select_image:
#             # Ensure only one checkbox is checked
#             other_lines = record.tree_management_id.tree_ids.filtered(lambda l: l.id != record.id)
#             other_lines.write({'select_image': False})

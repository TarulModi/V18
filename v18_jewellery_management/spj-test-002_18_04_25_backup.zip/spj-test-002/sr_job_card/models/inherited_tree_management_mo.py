from odoo import models, fields, api, _


class TreeManagementMO(models.Model):
    _inherit = 'tree.management.mo'
    _order = 'id desc'

    receive_line_id = fields.Many2one('job.receive.line', string="MO/Job No.", order='id desc')

    # Override
    mo_no = fields.Many2one(
        related='receive_line_id.production_id',
        string='MO No.',
        required=True
    )
    product_id = fields.Many2one('product.product', string='SKU', related='receive_line_id.product_id', readonly=True)
    quantity = fields.Float(string='Order Quantity', related='receive_line_id.order_qty', readonly=True)
    return_piece = fields.Float(string='Rtn.Pcs', related='receive_line_id.rec_pcs', readonly=False)
    gross_weight = fields.Float(string='GrossWt', related='receive_line_id.rec_gwt', readonly=False)
    net_weight = fields.Float(string='NetWt', related='receive_line_id.rec_nwt', readonly=False)
    component_weight = fields.Float(string='Component Wt', related='receive_line_id.component_weight', readonly=False)
    unit = fields.Many2one('uom.uom', string='Unit', related='receive_line_id.production_id.product_uom_id', readonly=True)
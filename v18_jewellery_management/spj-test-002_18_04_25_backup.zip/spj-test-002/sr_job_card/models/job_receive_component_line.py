
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class JobReceiveComponentLine(models.Model):
    _name = 'job.receive.component.line'
    _description = 'Job Receive Component Line'
    _inherit = ['mail.thread']
    _rec_name = "product_id"
    _order = 'id desc'

    job_receive_id = fields.Many2one('job.receive', string="Job Receive", ondelete="cascade", tracking=True)
    product_id = fields.Many2one('product.product', string="Component", tracking=True)
    product_qty = fields.Float(string="Quantity", tracking=True)
    uom_id = fields.Many2one('uom.uom', string="Unit", tracking=True)
    location_id = fields.Many2one('stock.location', string="Source Location", tracking=True)

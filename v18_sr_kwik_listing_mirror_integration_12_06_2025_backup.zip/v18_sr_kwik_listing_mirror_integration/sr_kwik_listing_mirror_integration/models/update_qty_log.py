# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import fields, models, api, _


class srupdateQtyLog(models.Model):
    _name = "update.qty.log"
    _description = "Update QTY Log"
    _rec_name = "name"
    
    name = fields.Char('Integration Name', required=True)
    sales_order_id = fields.Many2one('sale.order',string='Sales Order Reference')
    purchase_order_id = fields.Many2one('purchase.order',string='Purchase Order Reference')
    picking_id = fields.Many2one('stock.picking',string="Picking Order Reference")
    # inventory_adjustment_id = fields.Many2one('stock.inventory',string="Inventory Adjustment Reference")
    move_id = fields.Many2one('stock.move',string="Move Reference")
    qty = fields.Float('QTY')
    pushed_qty = fields.Float('Pushed QTY to Listing Mirror')
    origin = fields.Char('Origin',required=True)
    product_id = fields.Many2one('product.product', string="Product")
    kit_product_id = fields.Many2one('product.product',string='Kit Product')



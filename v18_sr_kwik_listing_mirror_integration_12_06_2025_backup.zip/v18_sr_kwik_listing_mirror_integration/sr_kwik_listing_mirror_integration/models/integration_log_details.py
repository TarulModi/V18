# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import fields, models, api, _


class IntegrationLogDetails(models.Model):
    _name = "integration.log.details"
    _description = "Integration Log Details"
    _inherit = ['mail.thread']
    _rec_name = "integration_name"
    _order = 'id desc'

    integration_name = fields.Char('Integration Name', copy=False, tracking=True)
    start_date = fields.Date('Start Date', copy=False, tracking=True)
    end_date = fields.Date('End Date', copy=False, tracking=True)
    count = fields.Date('Count', copy=False, tracking=True)
    product_id = fields.Many2one('product.product', string="Product", copy=False, tracking=True)
    sale_order_id = fields.Many2one('sale.order', string="Sale Order", copy=False, tracking=True)
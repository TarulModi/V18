{
    'name': 'Job Card Issue Receive Management',
    'version': '1.0',
    'summary': 'Manage component and product issues/receipts in Manufacturing Orders',
    'author': 'Gaurav Goswami',
    'category': 'Manufacturing',
    'depends': ['base', 'mrp', 'hr', 'mail', 'mrp_account', 'jewellery_master', 'sr_secondary_uom_customization', 'silver_plusss'],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'views/job_issue_view.xml',
        'views/job_receive_view.xml',
        'views/inherited_manufacture_views.xml',
        'views/inherited_tree_management_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'OPL-1',
}

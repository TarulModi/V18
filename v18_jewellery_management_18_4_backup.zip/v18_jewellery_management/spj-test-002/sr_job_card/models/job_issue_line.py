
import time
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class JobIssueLine(models.Model):
    _name = 'job.issue.line'
    _inherit = ['mail.thread']
    _description = 'Job Issue Line'
    _rec_name = 'production_id'

    job_issue_id = fields.Many2one('job.issue', string="Job Issue", ondelete="cascade")
    production_id = fields.Many2one(
        'mrp.production',
        string='MO/Job No.',
        domain="[('state', '=', 'confirmed')]",
        required=True,
        tracking=True
    )
    product_id = fields.Many2one(string='SKU', related='production_id.product_id', readonly=True, tracking=True)
    metal_id = fields.Many2one(string='Metal', related='product_id.metal', readonly=True, tracking=True)
    colour_id = fields.Many2one(string='Colour', related='product_id.color', readonly=True, tracking=True)
    fineness = fields.Float(string='Fineness', related='product_id.fineness', readonly=True, tracking=True)
    size_id = fields.Many2one(string='Size', related='product_id.size_id', readonly=True, tracking=True)
    order_qty = fields.Float(string='Order QTY', related='production_id.product_qty', readonly=True, tracking=True)
    sc_order_qty = fields.Float(string='Secondary Order QTY', related='production_id.secondary_qty', readonly=True, tracking=True)
    # tree_no = fields.Char(string='Tree No', related='production_id.tree_number', readonly=True, tracking=True)
    tree_id = fields.Many2one(string='Tree No', related='production_id.tree_id', readonly=True, tracking=True)
    workcenter_id = fields.Many2one(related='job_issue_id.workcenter_id', string="Work Center", tracking=True)
    pcs = fields.Float(string="PCS", related='production_id.product_qty', readonly=False, tracking=True)
    issue_gross_weight = fields.Float(string='Gr.Wt', readonly=False, tracking=True)
    issue_net_weight = fields.Float(string='Nt.Wt', readonly=False, tracking=True)
    issue_component_weight = fields.Float(string='Comp.Wt', readonly=False, tracking=True)
    issue_stone_weight = fields.Float(string='Stn.Wt-Gm', readonly=False, tracking=True)
    issue_exact_weight = fields.Float(string='Ext.Wt', readonly=False, tracking=True)
    receive_id = fields.Many2one('job.receive', string='Receive', readonly=True, tracking=True)
    receive_line_id = fields.Many2one('job.receive.line', string='Receive Line', readonly=True, tracking=True)
    state = fields.Selection([('draft', 'Draft'), ('issue', 'Issued'), ('in_progress', 'In Progress'), ('done', 'Done'), ('return', 'Return')], string="Status",
                             default="draft", tracking=True)
    start_time = fields.Datetime('Start Time', store=True, tracking=True)
    end_time = fields.Datetime('End Time', store=True, tracking=True)

    def button_start(self):
        for rec in self:
            rec.write({
                'start_time' : fields.Datetime.now(),
                'state' : 'in_progress',
            })

    def button_done(self):
        for rec in self:
            rec.write({
                'end_time': fields.Datetime.now(),
                'state': 'done',
            })

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise ValidationError(
                    f"Sorry, you can only delete records in the draft state.")
        return super(JobIssueLine, self).unlink()
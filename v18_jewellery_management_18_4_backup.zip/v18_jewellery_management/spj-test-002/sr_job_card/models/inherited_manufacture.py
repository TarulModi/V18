from odoo import models, fields


class mrpProduction(models.Model):
    _inherit = 'mrp.production'

    tree_id = fields.Many2one("tree.management", string="Tree No.", copy=False, tracking=True)
from odoo import models, fields, api, _


class TreeManagementMO(models.Model):
    _inherit = 'tree.management.mo'

    receive_line_id = fields.Many2one('job.receive.line', string="MO/Job No.")

    # Override
    mo_no = fields.Many2one(
        related='receive_line_id.production_id',
        string='MO No.',
        required=True
    )
    product_id = fields.Many2one('product.product', string='SKU', related='receive_line_id.product_id', readonly=True)
    quantity = fields.Float(string='Order Quantity', related='receive_line_id.order_qty', readonly=True)
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class JobReceive(models.Model):
    _name = 'job.receive'
    _inherit = ['mail.thread']
    _description = 'Job Receive'
    _rec_name = 'name'

    name = fields.Char(string="I/R ID No.", required=True, copy=False, readonly=True, default='New', tracking=True)
    date = fields.Date(string="Date", default=fields.Date.context_today, tracking=True)
    workcenter_id = fields.Many2one('mrp.workcenter', string="Process (Work Center)", tracking=True, copy=False)
    department_id = fields.Many2one('hr.department', string="Department", tracking=True)
    worker_id = fields.Many2one('hr.employee', string="Worker", tracking=True)
    state = fields.Selection([('draft', 'Draft'), ('issue', 'Issued')], string="Status", default="draft", tracking=True)
    job_receive_line_ids = fields.One2many('job.receive.line', 'job_receive_id', string="Receive Details")
    job_receive_component_ids = fields.One2many('job.receive.component.line', 'job_receive_id', string="Receive Component Details")
    job_issue_line_ids = fields.Many2many(
        'job.issue.line',
        domain="[('state', '=', 'confirmed')]",
        copy=False
    )

    @api.onchange('workcenter_id')
    def onchange_workcenter_id(self):
        if self.workcenter_id:
            self.job_receive_line_ids = [(5, 0)]
            workorder_ids = self.env['job.issue.line'].search([
                ('workcenter_id', '=', self.workcenter_id.id),
                ('state', '=', 'done')
            ])
            if workorder_ids:
                existing_ids = self.job_issue_line_ids.ids
                unique_ids = list(set(workorder_ids.ids) - set(existing_ids))
                if unique_ids:
                    self.job_issue_line_ids = [(6, 0, existing_ids + unique_ids)]
            else:
                self.job_issue_line_ids = [(6, 0, [])]
            # if workorder_ids:
            #     self.job_issue_line_ids = [(6, 0, workorder_ids.ids)]
            # else:
            #     self.job_issue_line_ids = [(6, 0, [])]

    @api.constrains('job_receive_line_ids')
    def _check_job_receive_line_ids(self):
        machin_list = []
        for record in self:
            for line in record.job_receive_line_ids:
                if line.job_issue_line_id.id in machin_list:
                    raise ValidationError(
                        f"Sorry, you can't set the same production '{line.job_issue_line_id.display_name}' multiple times.")
                else:
                    machin_list.append(line.job_issue_line_id.id)

    @api.model
    def create(self, vals):
        if vals.get('name', "New") == "New":
            vals['name'] = self.env['ir.sequence'].next_by_code('job.receive') or "New"
        return super(JobReceive, self).create(vals)

    def action_confirm(self):
        self.write({'state': 'issue'})
        if self.job_receive_line_ids:
            for line in self.job_receive_line_ids:
                line.job_issue_line_id.write({
                    'receive_id' : line.job_receive_id.id,
                    'receive_line_id' : line.id,
                    'state' : 'return',
                })

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise ValidationError(
                    f"Sorry, you can't delete issue records")
        return super(JobReceive, self).unlink()
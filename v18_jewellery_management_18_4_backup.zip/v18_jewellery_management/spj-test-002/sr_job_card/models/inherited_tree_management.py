from odoo import models, fields, api, _


class TreeManagement(models.Model):
    _inherit = 'tree.management'

    receive_line_ids = fields.Many2many('job.receive.line', string="Job Receive Lines")

    @api.onchange('work_center')
    def onchange_workcenter_id(self):
        if self.work_center:
            self.tree_ids = [(5, 0)]
            job_receive_line_ids = self.env['job.receive.line'].search(
                [('job_receive_id.state', '=', 'issue'), ('workcenter_id', '=', self.work_center.id)])
            if job_receive_line_ids:
                self.receive_line_ids = [(6, 0, job_receive_line_ids.ids)]
            else:
                self.receive_line_ids = [(6, 0, [])]

    def action_issue_to_casting(self):
        result = super(TreeManagement, self).action_issue_to_casting()
        if self.tree_ids:
            for tree_id in self.tree_ids:
                if tree_id and tree_id.mo_no:
                    tree_id.mo_no.tree_id = self.id
        return result
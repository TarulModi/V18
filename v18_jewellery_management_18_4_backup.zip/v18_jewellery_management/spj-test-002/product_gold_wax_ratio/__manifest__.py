{
    'name': 'Product Gold Wax Ratio',
    'version': '1.0',
    'category': 'Product',
    'summary': 'Add Gold Wax Ratio to Product',
    'depends': ['product'],
    'data': [
        'views/product_gold_wax_ratio_views.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'application': False,
}

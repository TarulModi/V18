from odoo import models, fields, api
from odoo.exceptions import ValidationError

class RouteTemplate(models.Model):
    _name = 'route.template'
    _description = 'Route Template'

    name = fields.Char(string='Template Name', required=True)
    deactivate = fields.Boolean(string='Deactivate', default=False)  # New checkbox field
    operation_ids = fields.One2many('route.template.operation', 'template_id', string='Operations')


class RouteTemplateOperation(models.Model):
    _name = 'route.template.operation'
    _description = 'Route Template Operation'

    name = fields.Char(string='Operation', required=True)
    template_id = fields.Many2one('route.template', string='Template', ondelete='cascade')
    workcenter_id = fields.Many2one('mrp.workcenter', string='Work Center', required=True)
    duration = fields.Float(string='Duration', required=True)
    # sequence = fields.Integer(string='Sequence', required=True)


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    route_template_id = fields.Many2one('route.template', string='Route Template', domain="[('deactivate', '=', False)]")

    @api.onchange('route_template_id')
    def _onchange_route_template_id(self):
        if self.state in ['draft'] and self.route_template_id:
            self.workorder_ids = [(5, 0, 0)]  # Clear existing work orders
            workorder_list = []
            for operation in self.route_template_id.operation_ids:
                workorder_values = {
                    'production_id': self.id,  # Link to the current manufacturing order
                    'name': operation.name,
                    'workcenter_id': operation.workcenter_id.id,
                    'duration_expected': operation.duration,
                    'product_id': self.product_id.id,
                    'product_uom_id': self.product_uom_id.id,
                    'qty_production': self.product_qty,
                    # 'sequence': operation.sequence,
                }
                workorder_list.append((0, 0, workorder_values))
            self.workorder_ids = workorder_list

    def write(self, vals):
        if 'route_template_id' in vals and self.state not in ['draft']:
            raise ValidationError("You cannot change the Route Template for manufacturing orders that are not in draft state.")
        return super(MrpProduction, self).write(vals)

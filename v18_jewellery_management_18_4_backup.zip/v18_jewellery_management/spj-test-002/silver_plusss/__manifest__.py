{
    'name': 'Silver Plus 2',
    'version': '1.0',
    'category': 'Manufacturing',
    'summary': 'Manage tree information and related manufacturing orders',
    'author': 'Gaurav Goswami',
    'depends': ['base', 'mrp', 'product'],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/tree_management_views.xml',
        'views/product_template_views.xml',
        'views/manufacture_views.xml',

    ],
    # 'images': ['static/description/icon.png'],
    'installable': True,
    'application': False,
}

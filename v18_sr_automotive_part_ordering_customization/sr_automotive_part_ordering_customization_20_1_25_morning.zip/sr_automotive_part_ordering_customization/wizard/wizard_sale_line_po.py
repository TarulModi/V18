# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class wizardSaleLinePO(models.TransientModel):
    _name = 'wizard.sale.line.po'
    _desciption = 'Sale Line PO'

    def _default_po_line(self):
        if self.env.context.get('sale_line_id'):
            sale_line_id = self.env['sale.order.line'].browse([self.env.context.get('sale_line_id')]).exists()
            if sale_line_id:
                po_line_ids = self.env['purchase.order.line'].search([('sale_order_line_id', '=', sale_line_id.id),
                                                                      ('product_id', '=', sale_line_id.product_id.id)])
                return [(6, 0, po_line_ids.ids)]
        return []

    po_line_ids = fields.Many2many('purchase.order.line', default=_default_po_line)
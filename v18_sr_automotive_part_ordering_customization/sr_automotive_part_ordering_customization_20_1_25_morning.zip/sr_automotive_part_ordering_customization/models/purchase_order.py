# -*- coding: utf-8 -*-

from odoo import fields, api, models, _, Command

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    sale_line_id = fields.Many2one('sale.order.line')
    sale_id = fields.Many2one('sale.order', copy=False)
    location_id = fields.Many2one('stock.location', related='partner_id.location_id', string='Location')

    @api.onchange('partner_id')
    def _onchange_partner(self):
        if self.partner_id and self.partner_id.location_id:
            picking_type = self.env['stock.picking.type'].search([
                ('code', '=', 'incoming'),
                ('default_location_dest_id', '=', self.partner_id.location_id.id)
            ], limit=1)
            if picking_type:
                self.picking_type_id = picking_type

    def button_confirm(self):
        result = super(PurchaseOrder, self).button_confirm()
        for order in self.picking_ids:
            if order.move_ids_without_package:
                for rec in order.move_ids_without_package:
                    rec.quantity = rec.product_uom_qty
            order.button_validate()
        return result

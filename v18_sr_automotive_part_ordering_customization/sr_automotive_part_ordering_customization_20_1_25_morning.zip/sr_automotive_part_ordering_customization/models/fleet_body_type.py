# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class FleetBodyType(models.Model):
    _name = 'fleet.body.type'
    _description = 'Body Type'

    name = fields.Char("Name")
# -*- coding: utf-8 -*-

from odoo import fields, api, models, _


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    default_code = fields.Char(
        'Amicco SKU Code', compute='_compute_default_code',
        inverse='_set_default_code', store=True)
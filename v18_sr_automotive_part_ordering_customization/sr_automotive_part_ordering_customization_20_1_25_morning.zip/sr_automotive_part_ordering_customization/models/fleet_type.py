# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class FleetType(models.Model):
    _name = 'fleet.type'
    _description = 'Fleet Type'

    name = fields.Char("Name")
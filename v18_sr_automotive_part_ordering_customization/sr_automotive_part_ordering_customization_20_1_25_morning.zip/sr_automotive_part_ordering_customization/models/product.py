# -*- coding: utf-8 -*-

from odoo import fields, api, models, _


class ProductVariant(models.Model):
    _inherit = 'product.product'

    default_code = fields.Char('Amicco SKU Code', index=True)
    vehicle_ids = fields.Many2many('fleet.vehicle', 'product_vehicle_rel', 'product_id', 'vehicle_id', string='Models')
    brand_line_ids = fields.One2many('product.brand.line', 'product_id', string="Brand Line")
    model_code_ids = fields.One2many('product.model.code', 'product_id', string="Model code Data")
    product_group_ids = fields. Many2many('product.product', 'prduct_group_rel', 'product_id', 'group_id', string='Product Groups')
    product_variant_seller_ids = fields.One2many('product.supplierinfo', 'product_id')

    # override base function
    @api.depends("product_tmpl_id.write_date")
    def _compute_write_date(self):
        for record in self:
            record.write_date = max(record.write_date or self.env.cr.now(), record.product_tmpl_id.write_date or self.env.cr.now())

    @api.model_create_multi
    def create(self, vals_list):
        res = super().create(vals_list)
        for rec in res:
            code = ''
            if rec.name:
                if len(rec.name) >= 4:
                    code = rec.name[:4]
                elif len(rec.name) >= 1:
                    code = rec.name
            if rec.product_template_attribute_value_ids:
                value_name = rec.product_template_attribute_value_ids[0].product_attribute_value_id.name
                code += '-'
                if len(value_name) >= 4:
                    code += value_name[:4]
                elif len(value_name) >= 1:
                    code += value_name
            code += '-' + str(rec.id)
            rec.default_code = code
        return res

    def write(self, values):
        code = ''
        for rec in self:
            if values.get('name') or values.get('product_template_attribute_value_ids'):
                if values.get('name'):
                    name = values.get('name')
                else:
                    name = rec.name
                if values.get('product_template_attribute_value_ids'):
                    value = rec.product_template_attribute_value_ids[0].product_attribute_value_id.name
                else:
                    value = rec.product_template_attribute_value_ids[0].product_attribute_value_id.name
                if name:
                    if len(name) >= 4:
                        code = name[:4]
                    elif len(name) >= 1:
                        code = name
                if value:
                    code += '-'
                    if len(value) >= 4:
                        code += value[:4]
                    elif len(value) >= 1:
                        code += value
                code += '-' + str(rec.id)
                values['default_code'] = code
        res = super(ProductVariant, self).write(values)
        return res
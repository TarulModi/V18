# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class FleetVehicle(models.Model):
    _inherit = 'fleet.vehicle'
    _rec_name = "import_display_name"

    vehicle_year_ids = fields.One2many('fleet.vehicle.year', 'vehicle_id', 'Vehicle Year')
    generation_id = fields.Many2one('fleet.generation')
    type_id = fields.Many2one('fleet.type')
    body_type_id = fields.Many2one('fleet.body.type')
    fleet_variant = fields.Char('Variant')
    import_display_name = fields.Char("Display Name")
    fuel_type = fields.Selection(selection_add=[
        ('petrol', 'Petrol'),
    ], ondelete={'petrol': 'cascade'})

    # @api.model
    # def name_search(self, name='', args=None, operator='ilike', limit=100):
    #     try:
    #         if isinstance(int(name), int):
    #             model_ids = self.env['fleet.vehicle']
    #             for rec in model_ids.search([]):
    #                 for year in rec.vehicle_year_ids:
    #                     if year.start_year <= int(name) <= year.end_year and rec not in model_ids:
    #                         model_ids += rec
    #             return [(model.id, model.display_name) for model in model_ids.sudo()]
    #         else:
    #             return super(FleetVehicle, self).name_search(name, args, operator, limit)
    #     except:
    #         return super(FleetVehicle, self).name_search(name, args, operator, limit)
    #     return super(FleetVehicle, self).name_search(name, args, operator, limit)
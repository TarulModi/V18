# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class FleetGeneration(models.Model):
    _name = 'fleet.generation'
    _description = 'Vehicle Generation'

    name = fields.Char("Name")
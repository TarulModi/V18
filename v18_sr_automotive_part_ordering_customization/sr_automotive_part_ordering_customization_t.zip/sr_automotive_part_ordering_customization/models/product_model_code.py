# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class ProductModelCode(models.Model):
    _name = 'product.model.code'
    _description = 'Product Model Code'

    product_id = fields.Many2one('product.product')
    fleet_vehicle_id = fields.Many2one('fleet.vehicle', "Model")
    code = fields.Char("OEM SKU Code")
    brand_id = fields.Many2one('product.brand', "Brand")
# -*- coding: utf-8 -*-

from odoo import fields, api, models, _, Command

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    sale_line_id = fields.Many2one('sale.order.line')
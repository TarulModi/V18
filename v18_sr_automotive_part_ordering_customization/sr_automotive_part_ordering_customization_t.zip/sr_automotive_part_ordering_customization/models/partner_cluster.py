# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class ProductCluster(models.Model):
    _name = 'partner.cluster'
    _description = 'Partner Cluster'

    name = fields.Char("Name")
    city = fields.Char("City")
    display_name = fields.Char("Ref", compute='_compute_cluster')

    @api.depends('city')
    def _compute_cluster(self):
        for rec in self:
            rec.display_name = rec.city[:3] + '_' + str(rec.id) if rec.city else ''
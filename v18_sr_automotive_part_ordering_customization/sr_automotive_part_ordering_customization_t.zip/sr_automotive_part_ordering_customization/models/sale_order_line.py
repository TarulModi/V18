# -*- coding: utf-8 -*-

from odoo import fields, api, models, _, Command

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    def view_po_detail(self):
        return {
            'name': _("Purchase Details"),
            'type': 'ir.actions.act_window',
            'views': [(False, 'form')],
            'res_model': 'wizard.sale.line.po',
            'target': 'new',
            'context': {"sale_line_id": self.id},
        }
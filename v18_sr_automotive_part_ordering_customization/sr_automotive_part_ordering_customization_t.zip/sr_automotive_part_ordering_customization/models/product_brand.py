# -*- coding: utf-8 -*-

from odoo import fields, api, models, _

class ProductBrand(models.Model):
    _name = 'product.brand'
    _description = 'Product Brand'

    name = fields.Char("Name")
    type = fields.Selection([('imported', 'Imported'),
                             ('oem', 'OEM'),
                             ('oes', 'OES')])
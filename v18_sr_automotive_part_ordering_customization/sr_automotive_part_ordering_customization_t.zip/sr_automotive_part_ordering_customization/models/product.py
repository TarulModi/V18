# -*- coding: utf-8 -*-

from odoo import fields, api, models, _


class ProductVariant(models.Model):
    _inherit = 'product.product'

    default_code = fields.Char('Amicco SKU Code', index=True)
    vehicle_ids = fields.Many2many('fleet.vehicle', 'product_vehicle_rel', 'product_id', 'vehicle_id', string='Models')
    brand_line_ids = fields.One2many('product.brand.line', 'product_id', string="Brand Line")
    model_code_ids = fields.One2many('product.model.code', 'product_id', string="Model code Data")
    product_group_ids = fields. Many2many('product.product', 'prduct_group_rel', 'product_id', 'group_id', string='Product Groups')
    product_variant_seller_ids = fields.One2many('product.supplierinfo', 'product_id')

    # override base function
    @api.depends("product_tmpl_id.write_date")
    def _compute_write_date(self):
        for record in self:
            record.write_date = max(record.write_date or self.env.cr.now(), record.product_tmpl_id.write_date or self.env.cr.now())
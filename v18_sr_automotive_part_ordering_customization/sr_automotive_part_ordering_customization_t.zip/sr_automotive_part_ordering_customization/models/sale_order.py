# -*- coding: utf-8 -*-

from odoo import fields, api, models, _, Command

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    order_line = fields.One2many(
        comodel_name='sale.order.line',
        inverse_name='order_id',
        string="Order Lines",
        copy=False, auto_join=True)
    vehicle_id = fields.Many2one('fleet.vehicle', 'Model')
    product_supplier_ids = fields.One2many('sale.product.supplier',
                                        'sale_id', copy=False)

    @api.onchange('order_line')
    def _onchange_product_suppliers(self):
        for rec in self:
            product_supplier_vals = [(5, 0, 0)]
            for line in rec.order_line:
                if line.product_id:
                    if line.virtual_available_at_date < line.product_uom_qty:
                        variant_seller_ids = self.env['product.supplierinfo'].search([('id', 'in', line.product_id.variant_seller_ids.ids)], order="priority")
                        for purchase_supplier in variant_seller_ids:
                            vals = {
                                'sale_line_id': line._origin.id or line.id,
                                'sale_id': rec.id,
                                'vendor_id': purchase_supplier.partner_id.id,
                                'price': purchase_supplier.price,
                                'currency_id': purchase_supplier.currency_id.id or False,
                            }
                            product_supplier_vals.append((0, 0, vals))
            rec.product_supplier_ids = product_supplier_vals

    def open_search_vehicle(self):
        return {
            'name': _("Filter Sale Vehicle Model"),
            'type': 'ir.actions.act_window',
            'views': [(False, 'form')],
            'res_model': 'sr.filter.sale.vehicle.model',
            'target': 'new',
        }

    def copy_data(self, default=None):
        default = dict(default or {})
        default.setdefault('order_line', [])
        vals_list = super().copy_data(default=default)
        return vals_list

    @api.model_create_multi
    def create(self, vals_list):
        sale_ids = super().create(vals_list)
        for rec in sale_ids:
            rec._onchange_product_suppliers()
        return sale_ids
# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from . import sr_mass_duplicate_sales_order
from . import sr_mass_duplicate_purchase_order
from . import sr_mass_duplicate_invoices
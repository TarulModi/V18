{
    'name': 'Consignment Management',
    'version': '1.0',
    'summary': 'Manage Consignments',
    'description': 'A module to manage vendor consignments in Odoo.',
    'category': 'Inventory',
    'author': 'Gaurav Goswami',
    'depends': ['base', 'purchase', 'product', 'stock'],
    'data': [
        'data/sequences.xml',
        'views/consignment_views.xml',
        'views/consignment_sorting_views.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'application': True,
}

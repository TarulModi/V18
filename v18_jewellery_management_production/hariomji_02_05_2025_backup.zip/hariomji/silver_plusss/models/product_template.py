from odoo import models, fields


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    tree_number = fields.Char(string='Tree No.', readonly=True, store=True)

# class ProductTemplate(models.Model):
#     _inherit = 'product.template'
#
#     metal = fields.Char(string='Metal')
#     fineness = fields.Float(string='Fineness', digits=(16, 3))
#     color = fields.Char(string='Color')
#     size = fields.Char(string='Size')



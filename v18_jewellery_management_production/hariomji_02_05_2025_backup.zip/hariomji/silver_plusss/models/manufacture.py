from odoo import models, fields


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    job_no = fields.Char(string='Job No', store=True)
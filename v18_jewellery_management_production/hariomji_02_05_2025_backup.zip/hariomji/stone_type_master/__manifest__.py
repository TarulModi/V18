{
    'name': "Stone Type Master",
    'version': '1.0',
    'author': "Gaurav Goswami",
    'category': 'Custom',
    'summary': "Manage different types of stones",
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/stone_type_view.xml',
        'views/stone_quality_view.xml',
        'views/stone_group_view.xml',
        'views/stone_master_view.xml',
        'views/shape_master_view.xml'
        # 'views/stone_type_menu.xml',
    ],
    'installable': True,
    'application': True,
}

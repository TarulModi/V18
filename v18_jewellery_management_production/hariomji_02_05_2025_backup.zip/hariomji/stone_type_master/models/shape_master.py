from odoo import models, fields, api

class StoneTypeMaster(models.Model):
    _name = "shape.master"
    _description = "Shape Master"
    _rec_name = "shape_master"

    shape_master = fields.Char(string="Shape Name", required=True)
    shape_master_code = fields.Char(string="Shape Code", required=True, unique=True)
    shape_master_description = fields.Char(string="Shape Description")
    created_date = fields.Datetime(string="Created Date", default=fields.Datetime.now, readonly=True)
    last_modified_date = fields.Datetime(string="Last Modified Date", default=fields.Datetime.now)

    @api.model
    def create(self, vals):
        vals['created_date'] = fields.Datetime.now()
        vals['last_modified_date'] = fields.Datetime.now()
        return super(StoneTypeMaster, self).create(vals)

    def write(self, vals):
        vals['last_modified_date'] = fields.Datetime.now()
        return super(StoneTypeMaster, self).write(vals)

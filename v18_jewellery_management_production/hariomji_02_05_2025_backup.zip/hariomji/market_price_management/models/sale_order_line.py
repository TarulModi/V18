from odoo import models, fields, api

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    bom_id = fields.Many2one(
        'mrp.bom',
        string="BOM",
        domain="[('product_tmpl_id', '=', product_template_id)]")

    metal_market_rate = fields.Float(string="Metal Market Rate", readonly=True, store=True,  compute='_compute_metal_market_rate')

    computed_bom_cost = fields.Float(
        string="Cost(Mkt)",
        readonly=True,
        store=True,
        compute='_compute_bom_cost'
    )

    @api.onchange('product_id')
    def _onchange_product_id_set_bom(self):
        """ Clear BOM when product changes to ensure only valid BOMs are selected """
        self.bom_id = False

        # Field to store the Metal Market Rate



    @api.depends('bom_id')
    def _compute_metal_market_rate(self):
        for line in self:
            # Initialize the market rate
            metal_market_rate = 0.0

            # If a BOM is selected, check its components
            if line.bom_id:
                for component in line.bom_id.bom_line_ids:
                    product = component.product_id
                    # Check if the product has a market price set
                    if product.market_price:
                        metal_market_rate = product.market_price
                        break  # Exit once we find the first market-priced product

            # Set the Metal Market Rate
            line.metal_market_rate = metal_market_rate

    @api.depends('bom_id')
    def _compute_bom_cost(self):
        for line in self:
            total_cost = 0.0

            if line.bom_id:
                for component in line.bom_id.bom_line_ids:
                    product = component.product_id

                    # Use market price if available, otherwise use standard cost
                    component_cost = product.market_price if product.market_price else product.standard_price

                    # Multiply by the required quantity in BOM
                    total_cost += component_cost * component.product_qty

            line.computed_bom_cost = total_cost

from odoo import models, fields

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_market_product = fields.Boolean(string="Gold Product")
    market_price = fields.Float(string="Market Price")

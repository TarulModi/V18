
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class JobIssueLineComponent(models.Model):
    _name = 'job.issue.line.component'
    _description = 'Job Issue Line Component'
    _inherit = ['mail.thread']
    _rec_name = "job_issue_id"
    _order = 'id desc'

    job_issue_id = fields.Many2one('job.issue', string="Job Issue", ondelete="cascade", tracking=True)
    job_issue_line_id = fields.Many2one('job.issue.line', string="Job Issue Line", tracking=True)
    production_id = fields.Many2one(
        related="job_issue_line_id.production_id",
        tracking=True
    )
    workcenter_id = fields.Many2one(related="job_issue_line_id.workcenter_id", string="Process (Work Center)", tracking=True)
    date = fields.Date(string="Date", default=fields.Date.context_today, tracking=True)
    component_ids = fields.One2many('job.issue.line.component.line', 'job_issue_line_component_id', String="Component", tracking=True)

    # @api.model
    # def default_get(self, fields):
    #     res = super(JobIssueLineComponent, self).default_get(fields)
    #     active_id = self.env['job.issue.line'].browse(self._context.get('active_id'))
    #     if active_id:
    #         component_list = []
    #         if active_id and active_id.production_id and active_id.production_id.move_raw_ids:
    #             for line in active_id.production_id.move_raw_ids:
    #                 component_list.append((0, 0, {
    #                     'product_id': line.product_id.id,
    #                     'product_qty': line.product_qty,
    #                     'location_id': line.location_id.id,
    #                     'move_id': line.id,
    #                     'job_issue_id': active_id.job_issue_id.id,
    #                     'job_issue_line_id': active_id.id
    #                 }))
    #         res.update({
    #             'job_issue_id': active_id.job_issue_id.id,
    #             'job_issue_line_id': active_id.id,
    #             # 'component_ids': component_list
    #         })
    #     return res


from odoo import models, fields, api, _
from odoo.exceptions import UserError


class JobReceiveLineComponentLine(models.Model):
    _name = 'job.receive.line.component.line'
    _description = 'Job Receive Component Line'
    _inherit = ['mail.thread']
    _rec_name = "product_id"
    _order = 'id desc'

    # job_issue_line_component_id = fields.Many2one('job.issue.line.component', string="Job Issue Component", ondelete="cascade", tracking=True)
    job_receive_line_id = fields.Many2one('job.receive.line', string="Job Receive Line", tracking=True)
    product_id = fields.Many2one('product.product', string="Component", tracking=True)
    product_qty = fields.Float(string="Quantity", tracking=True)
    uom_id = fields.Many2one(related="product_id.uom_id", string="Unit", tracking=True)
    location_id = fields.Many2one('stock.location', string="Source Location", tracking=True)
    move_id = fields.Many2one('stock.move', string="Move ID", tracking=True)
    job_receive_id = fields.Many2one('job.receive', string="Job Receive", ondelete="cascade", tracking=True)

    colour_id = fields.Many2one(string='Colour', related='product_id.color', readonly=True, tracking=True)
    size_id = fields.Many2one(string='Size', related='product_id.size_id', readonly=True, tracking=True)
    iss_wt_pcs = fields.Float(string="Iss WT/PCS", tracking=True)
    iss_prev_wt = fields.Float(string="Iss Prev.WT", tracking=True)
    issue_pcs = fields.Float(string="Iss PCS", tracking=True)
    issue_wt = fields.Float(string="Iss WT", tracking=True)
    iss_used_pcs = fields.Float(string="Iss Used PCS", tracking=True)
    iss_used_wt = fields.Float(string="Iss Used WT", tracking=True)
    rtn_pcs = fields.Float(string="Rtn PCS", tracking=True)
    rtn_nt_wt = fields.Float(string="Rtn NWT", tracking=True)
    loss_pcs = fields.Float(string="Loss PCS", tracking=True)
    loss_nt_wt = fields.Float(string="Loss NWT", tracking=True)
    loss_pr = fields.Float(string='Loss %', readonly=False, tracking=True)
    awl_loss_pr = fields.Float(string='AWL Loss %', readonly=False, tracking=True)
    used_pcs = fields.Float(string="Used PCS", tracking=True)
    used_nt_wt = fields.Float(string="Used NWT", tracking=True)
    break_pcs = fields.Float(string="Break PCS", tracking=True)
    break_wt = fields.Float(string="Break WT", tracking=True)
    setting_type = fields.Char(string="Sett. Type", tracking=True)
    remark = fields.Char(string="Remark", tracking=True)

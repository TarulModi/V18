
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class JobIssueLineComponentLine(models.Model):
    _name = 'job.issue.line.component.line'
    _description = 'Job Issue Component Line'
    _inherit = ['mail.thread']
    _rec_name = "product_id"
    _order = 'id desc'

    # job_issue_line_component_id = fields.Many2one('job.issue.line.component', string="Job Issue Component", ondelete="cascade", tracking=True)
    job_issue_line_id = fields.Many2one('job.issue.line', string="Job Issue Line", tracking=True)
    product_id = fields.Many2one('product.product', string="Component", tracking=True)
    product_qty = fields.Float(string="Quantity", tracking=True)
    uom_id = fields.Many2one(related="product_id.uom_id", string="Unit", tracking=True)
    location_id = fields.Many2one('stock.location', string="Source Location", tracking=True)
    move_id = fields.Many2one('stock.move', string="Move ID", tracking=True)
    job_issue_id = fields.Many2one('job.issue', string="Job Issue", ondelete="cascade", tracking=True)

    colour_id = fields.Many2one(string='Colour', related='product_id.color', readonly=True, tracking=True)
    size_id = fields.Many2one(string='Size', related='product_id.size_id', readonly=True, tracking=True)
    wt_pcs = fields.Float(string="WT/PCS", tracking=True)
    prev_wt = fields.Float(string="Prev.WT", tracking=True)
    issue_pcs = fields.Float(string="Iss PCS", tracking=True)
    issue_wt = fields.Float(string="Iss WT", tracking=True)
    used_pcs = fields.Float(string="Used PCS", tracking=True)
    used_nt_wt = fields.Float(string="Used NWT", tracking=True)

# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import models, fields, api, _


class ShowIssueLineComponent(models.TransientModel):
    _name = "show.issue.line.component.wizard"
    _description = "Show Issue Line Component Wizard"

    line_ids = fields.One2many('show.issue.line.component.wizard.line', 'wizard_id')

    @api.model
    def default_get(self, fields):
        res = super(ShowIssueLineComponent, self).default_get(fields)
        component_list = []
        active_id = self.env['job.issue.line'].browse(self._context.get('active_id'))
        workorder_ids = self.env['mrp.workorder'].search([
            ('workcenter_id', '=', active_id.workcenter_id.id),
            ('production_id.state', 'in', ['confirmed', 'progress']),
            ('production_id', 'in', active_id.production_id.ids)
        ])
        print("-----workorder_idsworkorder_idsworkorder_idsworkorder_idsworkorder_ids-----", workorder_ids)
        if workorder_ids:
            print("-----workorder_idsworkorder_idsworkorder_idsworkorder_idsworkorder_ids----222-----", workorder_ids)
            for workorder in workorder_ids:
                for line in workorder.move_raw_ids:
                    component_list.append((0, 0, {
                        'product_id': line.product_id.id,
                        'product_qty': line.product_qty,
                        'location_id': line.location_id.id,
                        'move_id': line.id,
                        'workcenter_id': active_id.workcenter_id.id,
                    }))
            print("-------component_list-----222-------", component_list)
        res.update({'line_ids': component_list})
        return res

    def submit_line_records(self):
        print("---------------callll----")
        active_id = self.env['job.issue.line'].browse(self._context.get('active_id'))
        component_list = []
        if self.line_ids:
            for line in self.line_ids:
                print("-----line.move+_id--------",line.move_id)
                if not line.move_id:
                    component_list.append((0, 0, {
                        'product_id': line.product_id.id,
                        'quantity': line.product_qty,
                        'location_id': line.location_id.id,
                        # 'raw_material_production_id':  active_id.production_id,
                    }))
            if component_list and active_id and active_id.production_id:
                print("-----active_id-------------",active_id)
                print("-----production_id-------------",active_id.production_id)
                active_id.production_id.write({
                    'move_raw_ids' : component_list
                })
                print("--------move_raw_ids----------",active_id.production_id.move_raw_ids)


class ShowIssueLineComponentLine(models.TransientModel):
    _name = "show.issue.line.component.wizard.line"
    _description = "Show Issue Line Component Wizard"

    wizard_id = fields.Many2one('show.issue.line.component.wizard', string="Wizard")
    product_id = fields.Many2one('product.product', string="Component")
    product_qty = fields.Float(string="Quantity")
    uom_id = fields.Many2one(related="product_id.uom_id", string="Unit")
    location_id = fields.Many2one('stock.location', string="Source Location")
    move_id = fields.Many2one('stock.move', string="Component ID")
    workcenter_id = fields.Many2one('mrp.workcenter', string="Process (Work Center)", tracking=True, copy=False)

    # @api.onchange('product_qty')
    # def onchange_product_qty(self):
    #     if self.move_id:
    #         self.move_id.quantity = self.product_qty
    #
    # @api.onchange('location_id')
    # def onchange_location_id(self):
    #     if self.move_id:
    #         self.move_id.location_id = self.location_id.id

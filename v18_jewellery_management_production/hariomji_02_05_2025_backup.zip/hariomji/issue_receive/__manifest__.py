{
    'name': 'Issue Receive Management',
    'version': '1.0',
    'summary': 'Manage component and product issues/receipts in Manufacturing Orders',
    'author': 'Gaurav Goswami',
    'category': 'Manufacturing',
    'depends': ['base', 'mrp'],
    'data': [
        'security/ir.model.access.csv',
        'views/issue_receive_view.xml',
        'views/issue_receive_menu.xml',
        'data/ir_sequence.xml',
    ],
    'installable': True,
    'application': True,
}

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ConsignmentLine(models.Model):
    _inherit = 'consignment.line'
    _description = 'Consignment Line'

    secondary_qty = fields.Float("Secondary Quantity", tracking=True, digits='Secondary')
    secondary_uom_id = fields.Many2one(related="product_id.secondary_uom_id")
    is_secondary = fields.Boolean(related="product_id.is_secondary")

    _sql_constraints = [
        ('check_secondary_qty_positive',
         'CHECK(secondary_qty >= 0)',
         'Secondary quantity must be a non-negative value.')
    ]

    @api.depends('qty_pcs', 'sum_sorted_qty')
    def _compute_balance_pcs(self):
        result = super(ConsignmentLine, self)._compute_balance_pcs()
        for record in self:
            if record.product_id and record.product_id.is_secondary:
                if record.product_id.dynamic_ratio > 0:
                    record.secondary_qty = record.product_id.dynamic_ratio * record.qty_pcs
                else:
                    record.secondary_qty = record.product_id.standard_ratio * record.qty_pcs

        return result

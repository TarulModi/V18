# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from . import inherited_product_template
from . import inherited_sale_order_line
from . import inherited_account_move_line
from . import inherited_purchase_order_line
from . import inherited_stock_move_line
from . import inherited_stock_move
from . import inherited_stock_quant
from . import inherited_stock_valuation_layer
from . import inherited_purchase_order
from . import inherited_stock_picking
from . import inherited_sale_order
from . import inherited_bom
from . import inherited_bom_line
from . import inherited_manufacturing
from . import inherited_consignment_line
from . import inherited_consignment_sorting_line

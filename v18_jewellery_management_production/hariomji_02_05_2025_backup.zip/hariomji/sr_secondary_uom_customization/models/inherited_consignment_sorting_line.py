from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ConsignmentSortingLine(models.Model):
    _inherit = 'consignment.sorting.line'
    _description = 'Consignment Line'

    secondary_qty = fields.Float("Secondary Quantity", tracking=True, digits='Secondary')
    secondary_uom_id = fields.Many2one(related="product_id.secondary_uom_id")
    is_secondary = fields.Boolean(related="product_id.is_secondary")

    _sql_constraints = [
        ('check_secondary_qty_positive',
         'CHECK(secondary_qty >= 0)',
         'Secondary quantity must be a non-negative value.')
    ]

    @api.onchange('qty_pcs')
    def _onchange_qty_pcs_pcs(self):
        if self.product_id and self.product_id.is_secondary:
            if self.product_id.dynamic_ratio > 0:
                self.secondary_qty = self.product_id.dynamic_ratio * self.qty_pcs
            else:
                self.secondary_qty = self.product_id.standard_ratio * self.qty_pcs
from . import product_gold_wax_ratio


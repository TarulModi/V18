from odoo import models, fields, api
from odoo.exceptions import UserError

class CreateMoWizard(models.TransientModel):
    _name = 'create.mo.wizard'
    _description = 'Create Manufacturing Order Wizard'

    sale_order_report_id = fields.Many2one('sale.order.report', string='Sale Order Report', readonly=True)
    product_id = fields.Many2one('product.product', string='Product', readonly=True)
    bom_id = fields.Many2one('mrp.bom', string='BOM', readonly=True)
    mo_quantity = fields.Float(string='Manufacturing Quantity', required=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        report = self.env['sale.order.report'].browse(self.env.context.get('active_id'))

        mo_list = self.env['mrp.production'].search([
            ('origin', '=', report.order_id.name),
            ('product_id', '=', report.product_id.id),
            ('state', 'not in', ['cancel'])
        ])
        manufactured_qty = sum(mo.product_qty for mo in mo_list)
        remaining_qty = report.product_uom_qty - manufactured_qty


        res.update({
            'sale_order_report_id': report.id,
            'product_id': report.product_id.id,
            'bom_id': report.bom_id.id,
            'mo_quantity': remaining_qty,
        })
        return res

    def create_mo(self):
        self.ensure_one()
        if self.mo_quantity <= 0:
            raise UserError("Manufacturing quantity must be greater than zero.")

        report = self.sale_order_report_id
        mo_list = self.env['mrp.production'].search([
            ('origin', '=', report.order_id.name),
            ('product_id', '=', report.product_id.id),
            ('state', 'not in', ['cancel'])
        ])
        manufactured_qty = sum(mo.product_qty for mo in mo_list)
        remaining_qty = report.product_uom_qty - manufactured_qty


        if self.mo_quantity > remaining_qty:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Confirm Overproduction',
                'res_model': 'confirm.mo.overproduce',
                'view_mode': 'form',
                'target': 'new',
                'context': {
                    'default_wizard_id': self.id,
                    'default_warning_message': f"You are trying to manufacture {self.mo_quantity}, "
                                               f"which is more than the remaining demand ({remaining_qty}). Proceed?"
                }
            }

        return self._create_mo_record()

    def _create_mo_record(self):
        mo = self.env['mrp.production'].create({
            'product_id': self.product_id.id,
            'product_qty': self.mo_quantity,
            'bom_id': self.bom_id.id,
            'origin': self.sale_order_report_id.order_id.name,
        })
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'mrp.production',
            'res_id': mo.id,
            'view_mode': 'form',
            'target': 'current',
        }


class ConfirmMoOverproduce(models.TransientModel):
    _name = 'confirm.mo.overproduce'
    _description = 'Confirm Overproduction Warning'

    wizard_id = fields.Many2one('create.mo.wizard', string="MO Wizard", required=True)
    warning_message = fields.Text(string="Warning", readonly=True)

    def confirm_overproduce(self):
        return self.wizard_id._create_mo_record()

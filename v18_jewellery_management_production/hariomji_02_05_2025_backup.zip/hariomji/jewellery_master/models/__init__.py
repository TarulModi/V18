from . import colour_master
from . import metal_master
from . import product_template
from . import sale_order_line
from . import collection_master
from . import size_master
from . import order_type
from . import sale_order
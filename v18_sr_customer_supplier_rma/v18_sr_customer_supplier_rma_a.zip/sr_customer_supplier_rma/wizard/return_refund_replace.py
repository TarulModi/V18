# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class ReturnRefundReplace(models.TransientModel):
    _name = 'return.refund.replace'
    _description = 'Return Refund Replace'

    line_ids = fields.One2many("return.refund.replace.line", 'return_refund_id')

    @api.model
    def default_get(self, fields_list):
        defaults = super().default_get(fields_list)
        if self.env.context.get('active_id'):
            rma_order_id = self.env['rma.order'].browse([self.env.context.get('active_id')]).exists()
            if rma_order_id and rma_order_id.rma_order_line_ids:
                line_lst = []
                for line in rma_order_id.rma_order_line_ids:
                    line_lst.append((0, 0, {
                        'product_id' : line.product_id.id,
                        'delivery_qty' : line.delivery_qty,
                        'return_id' : line.return_id.id,
                        'reject_id' : line.reject_id.id,
                        'rma_order_line_id': line.id
                    }))
                defaults['line_ids'] = line_lst
        return defaults

    def button_submit(self):
        if self.env.context.get('active_id'):
            rma_order_id = self.env['rma.order'].browse([self.env.context.get('active_id')]).exists()
            if rma_order_id and self.line_ids:
                for line in self.line_ids:
                    line.rma_order_line_id.write({
                        'return_id' : line.return_id.id,
                        'reject_id' : line.reject_id.id,
                        'return_qty' : line.return_qty
                    })


class ReturnRefundReplaceLine(models.TransientModel):
    _name = 'return.refund.replace.line'
    _description = 'Return Refund Replace Line'

    return_refund_id = fields.Many2one('return.refund.replace')
    rma_order_line_id = fields.Many2one('rma.order.line')
    product_id = fields.Many2one('product.product', string="Product")
    return_id = fields.Many2one('return.no.return', string="Return/NoReturn")
    reject_id = fields.Many2one('reject.reason', string="Reject Reason")
    delivery_qty = fields.Float('Delivery QTY')
    pending_qty = fields.Float('Pending QTY')
    return_qty = fields.Float('Return QTY')

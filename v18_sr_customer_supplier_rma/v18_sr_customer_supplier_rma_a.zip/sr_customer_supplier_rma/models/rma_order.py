# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################
from odoo import models, fields, api, _


class rmaOrder(models.Model):
    _name = 'rma.order'
    _description = 'RMA Order'
    _order = 'name desc'
    _rec_name = 'name'
    _inherit = ['mail.thread']

    name = fields.Char(string='RMA Reference', required=True, copy=False, readonly=True, default='New', tracking=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company, tracking=True)
    sale_order_id = fields.Many2one('sale.order', string='Sale Order', tracking=True, copy=False)
    subject = fields.Char(string='Subject', tracking=True, copy=False)
    crm_team_id = fields.Many2one('crm.team', string='Sales Channel', tracking=True, copy=False)

    date = fields.Datetime(string='Date', default=fields.Date.context_today, copy=False)
    deadline = fields.Datetime(string='Deadline', default=fields.Date.context_today, copy=False)
    user_id = fields.Many2one('res.users', string='Responsible', copy=False)
    priority = fields.Selection([
        ('0', 'Low'),
        ('1', 'Normal'),
        ('2', 'High'),
        ('3', 'Very High')
    ], string='Priority', copy=False)

    # Delivery Info
    stock_picking_id = fields.Many2one('stock.picking', string='Delivery Order', copy=False)
    delivery_partner_id = fields.Many2one('res.partner', string='Delivery Partner', copy=False)
    delivery_email = fields.Char(string='Email', related='delivery_partner_id.email', copy=False)
    delivery_phone = fields.Char(string='Phone', related='delivery_partner_id.phone', copy=False)

    # Invoice Info
    invoice_partner_id = fields.Many2one('res.partner', string='Invoice Partner', copy=False)
    invoice_email = fields.Char(string='Invoice Email', related='invoice_partner_id.email', copy=False)
    invoice_phone = fields.Char(string='Invoice Phone', related='invoice_partner_id.phone', copy=False)

    rma_order_line_ids = fields.One2many('rma.order.line', 'rma_order_id', copy=False, string="RMA Lines")
    rma_replaced_product_ids = fields.One2many('rma.replaced.product', 'rma_order_id', copy=False, string="Replaced Products")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('rma.order') or 'New'
        return super().create(vals_list)

    @api.onchange('sale_order_id')
    def onchange_sale_order(self):
        order_lines_data = [(5, 0)]
        if self.sale_order_id:
            print("-----self.sale_order_id.picking_ids-------",self.sale_order_id.picking_ids)
            if self.sale_order_id.picking_ids:
                picking_id = self.sale_order_id.picking_ids.filtered(
                    lambda r: r.picking_type_id.code == 'outgoing' and r.state == 'done')[:1]
                print("---Latest picking_id---------", picking_id)
                if picking_id:
                    self.stock_picking_id = picking_id.id

                # pickings = self.sale_order_id.picking_ids.filtered(
                #     lambda r: r.picking_type_id.code == 'outgoing' and r.state == 'done'
                # )
                # latest_picking = pickings.sorted(lambda r: r.date_done or r.create_date, reverse=True)[:1]
                # if latest_picking:
                #     picking_id = latest_picking[0]
                #     print("---Latest picking_id---------", picking_id)
                #     self.stock_picking_id = picking_id.id

            self.crm_team_id = self.sale_order_id.team_id.id
            self.user_id = self.sale_order_id.user_id.id
            self.delivery_partner_id = self.sale_order_id.partner_shipping_id.id
            self.invoice_partner_id = self.sale_order_id.partner_invoice_id.id

            if self.sale_order_id.order_line:
                for line in self.sale_order_id.order_line:
                    order_lines_data.append((0, 0, {
                        'product_id': line.product_id.id,
                        'delivery_qty': line.qty_delivered,
                        'price_before': line.price_unit,
                    }))
        self.rma_order_line_ids = order_lines_data

    def open_return_refund_replace_wizard(self):
        action = self.env['ir.actions.actions']._for_xml_id('sr_customer_supplier_rma.action_return_refund_replace_form')
        return action
# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from . import res_company
from . import res_config_settings
from . import reject_reason
from . import rma_order
from . import return_and_no_return
from . import rma_order_line
from . import rma_replaced_product
#from . import sale_order
#from . import stock_picking

# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import api, fields, models, _


class StockPicking(models.Model):
    _inherit = "stock.picking"

    def action_confirm(self):
        result = super(StockPicking, self).action_confirm()
        if self.move_ids_without_package:
            for move in self.move_ids_without_package:
                if move.move_line_ids:
                    for line in move.move_line_ids:
                        line.secondary_qty = line.move_id.secondary_qty
                        print("----sssss---------",line.secondary_qty)
        return result

    # def button_validate(self):
    #     result = super(StockPicking, self).button_validate()
    #     if self.move_ids_without_package:
    #         for move in self.move_ids_without_package:
    #             if move.move_line_ids:
    #                 for line in move.move_line_ids:
    #                     if line.product_stock_quant_ids:
    #                         for quant in line.product_stock_quant_ids:
    #                             quant.secondary_qty = line.secondary_qty
    #     return result
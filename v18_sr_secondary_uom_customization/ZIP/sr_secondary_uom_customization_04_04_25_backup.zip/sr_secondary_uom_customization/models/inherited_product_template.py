# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from odoo import _, api, fields, models, tools


class ProductTemplate(models.Model):
    _inherit = "product.template"

    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if 'secondary_uom_id' in fields_list and not res.get('secondary_uom_id'):
            res['secondary_uom_id'] = self._get_default_secondary_uom_id().id
        return res

    @tools.ormcache()
    def _get_default_secondary_uom_id(self):
        # Deletion forbidden (at least through unlink)
        return self.env.ref('uom.product_uom_unit')

    secondary_uom_id = fields.Many2one(
        'uom.uom', 'Secondary UOM',
        default=_get_default_secondary_uom_id, required=True, tracking=True)

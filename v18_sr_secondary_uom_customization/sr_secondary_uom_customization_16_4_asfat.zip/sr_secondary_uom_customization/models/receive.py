from odoo import models, fields

class IRTransaction(models.Model):
    _name = 'ir.transaction'
    _description = 'IR Transaction'
    _order = 'name desc'

    name = fields.Char(string="I/R ID No.", required=True, readonly=True, copy=False, default="New")
    type = fields.Selection([
        ('issue', 'Issue'),
        ('receive', 'Receive')
    ], string='Type', required=True)
    date = fields.Date(string='Date', default=fields.Date.today)
    process_id = fields.Many2one('mrp.routing.workcenter', string="Process")
    department_id = fields.Many2one('hr.department', string="Department")
    worker_id = fields.Many2one('hr.employee', string="Worker")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Done')
    ], string='Status', default='draft')

    issue_line_ids = fields.One2many('ir.transaction.line', 'issue_ref_id', string='Issue Lines', ondelete='cascade')
    # receive_line_ids = fields.One2many('ir.receive.line', 'receive_ref_id', string='Receive Lines', ondelete='cascade')


class IRTransactionLine(models.Model):
    _name = 'ir.transaction.line'
    _description = 'IR Transaction Line'

    issue_ref_id = fields.Many2one('ir.transaction', string='Issue Reference', ondelete='cascade')

    select_mo = fields.Boolean(string="Select MO")
    product_id = fields.Many2one('product.product', string="Product", index=True, ondelete='set null')
    mo_no = fields.Many2one('mrp.production', string='MO No', index=True, ondelete='set null')
    job_no_id = fields.Char(string="Job No.")
    category_id = fields.Many2one('product.category', string="Category")
    # metal_id = fields.Many2one('product.template', string="Metal"ondelete='set null')
    product_color = fields.Char(string="Color")
    fineness = fields.Char(string="Fineness")
    size_id = fields.Many2one('product.size', string="Size")
    unit = fields.Many2one('uom.uom', string="UOM")
    tree_no_id = fields.Char(string="Tree No.")
    pieces = fields.Float(string="Pieces")
    issue_gross_weight = fields.Float(string="Issue Gross Weight")
    issue_Net_weight = fields.Float(string="Issue Net Weight")
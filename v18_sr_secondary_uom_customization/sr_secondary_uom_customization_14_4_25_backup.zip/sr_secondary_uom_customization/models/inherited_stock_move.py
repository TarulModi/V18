# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) Sitaram Solutions (<https://sitaramsolutions.in/>).
#
#    For Module Support : info@sitaramsolutions.in  or Skype : contact.hiren1188
#
##############################################################################

from collections import defaultdict
from odoo import api, fields, models, _


class StockMove(models.Model):
    _inherit = "stock.move"

    secondary_qty = fields.Float("Secondary Quantity", tracking=True, digits='Secondary')
    secondary_uom_id = fields.Many2one(related="product_id.secondary_uom_id")
    is_secondary = fields.Boolean(related="product_id.is_secondary")

    _sql_constraints = [
        ('check_secondary_qty_positive',
         'CHECK(secondary_qty >= 0)',
         'Secondary quantity must be a non-negative value.')
    ]

    # @api.onchange('quantity')
    # def onchange_quantity(self):
    #     print("-----------sssssssssssssssssssssssssssssssssssssssssssss--------------",self._ids)
    #     if not any(self._ids):
    #         if self.product_id and self.product_id.dynamic_ratio > 0:
    #             self.secondary_qty = self.product_id.dynamic_ratio * self.quantity
    #         else:
    #             self.secondary_qty = self.product_id.standard_ratio * self.quantity

    @api.onchange('product_uom_qty')
    def onchange_product_uom_qty(self):
        if self.product_id and self.product_id.is_secondary:
            if self.product_id.dynamic_ratio > 0:
                self.secondary_qty = self.product_id.dynamic_ratio * self.product_uom_qty
            else:
                self.secondary_qty = self.product_id.standard_ratio * self.product_uom_qty

    # @api.depends('move_line_ids.quantity', 'move_line_ids.product_uom_id', 'move_line_ids.secondary_qty')
    # # def _compute_quantity(self):
    # # @api.depends('move_line_ids.lot_id', 'move_line_ids.quantity','move_line_ids.secondary_qty')
    # def _compute_lot_ids(self):
    #     result = super(StockMove, self)._compute_lot_ids()
    #     for record in self:
    #         sum_move_line = sum(record.move_line_ids.mapped('secondary_qty'))
    #         print("---sum_move_line---sum_move_line-------",sum_move_line)
    #         record.secondary_qty = sum_move_line
    #         # record.with_context({'write_stop':True}).write({'secondary_qty':sum_move_line})
    #         # print("---srecord.secondary_qty-------",record.secondary_qty)
    #
    #     return  result

    @api.depends('move_line_ids.quantity', 'move_line_ids.product_uom_id', 'move_line_ids.secondary_qty')
    def _compute_quantity(self):
        """ This field represents the sum of the move lines `quantity`. It allows the user to know
        if there is still work to do.

        We take care of rounding this value at the general decimal precision and not the rounding
        of the move's UOM to make sure this value is really close to the real sum, because this
        field will be used in `_action_done` in order to know if the move will need a backorder or
        an extra move.
        """
        if not any(self._ids):
            # onchange
            for move in self:
                # print("-------ifffififfifififfi------",move)
                # print("-------ifffififfifififfi---1---",move.move_line_ids)
                # print("-------ifffififfifififfi----2--",move.move_line_ids.quantity)
                # print("-------ifffififfifififfi-----3-",move.move_line_ids.secondary_qty)
                move.quantity = move._quantity_sml()
                print("-------ifffififfifififfi---5555555555555555---", move.quantity)
                sum_move_line = sum(move.move_line_ids.mapped('secondary_qty'))
                print("---sum_move_line---sum_move_line-------",sum_move_line)
                move.secondary_qty = sum_move_line
        else:
            # compute
            move_lines_ids = set()
            for move in self:
                move_lines_ids |= set(move.move_line_ids.ids)

            data = self.env['stock.move.line']._read_group(
                [('id', 'in', list(move_lines_ids))],
                ['move_id', 'product_uom_id'], ['quantity:sum']
            )
            print("-----elslellelele----data----", data)
            sum_qty = defaultdict(float)
            for move, product_uom, qty_sum in data:
                print("-----elslellelele----move----", move)
                print("-----elslellelele----product_uom----", product_uom)
                print("-----elslellelele----qty_sum----", qty_sum)
                uom = move.product_uom
                sum_qty[move.id] += product_uom._compute_quantity(qty_sum, uom, round=False)

            for move in self:
                move.quantity = sum_qty[move.id]
                print("-----elslellelele----aaaaaaaaaaaa----", move.quantity)

    def write(self, vals):
        # print("----11111111111-----move--write------", vals)
        result = super(StockMove, self).write(vals)
        # print("-=======22222222222222=====------------==============---ccccccccccccccc--------=",self.env.context)
        if 'secondary_qty' in vals and vals['secondary_qty'] and not 'move_line_ids' in vals:
            if self.move_line_ids:
                for line in self.move_line_ids:
                    if line.move_id.secondary_qty and line.move_id.quantity:
                        # print("--line.move_id.secondary_qty---qqqqqqqqqqqqqqqqqqq-----", line.move_id.secondary_qty)
                        # print("---line.move_id.quantity--qqqqqqqqqqqqqqqqqqq-----", line.move_id.quantity)
                        # secondary_qty = line.move_id.secondary_qty / line.move_id.quantity
                        # print("---------secondary_qty----qqqqqqqqqqqqqqqqqqq-----",secondary_qty)
                        # print("---------line.quantity----qqqqqqqqqq-----",line.quantity)
                        # print("----line.quantity * secondary_qty---qqqqqqqqqq-----",line.quantity * secondary_qty)
                        # line.secondary_qty = line.quantity * secondary_qty
                        line.secondary_qty = line.move_id.secondary_qty
                        # print("---------line.secondary_qty---qqqqqqq------",line.secondary_qty)
        if 'quantity' in vals and not 'secondary_qty' in vals:
            sum_move_line = sum(self.move_line_ids.mapped('secondary_qty'))
            print("---sum_move_line---sum_move_line-------", sum_move_line)
            if self.product_id and self.product_id.dynamic_ratio > 0:
                self.secondary_qty = self.product_id.dynamic_ratio * self.quantity
            else:
                self.secondary_qty = self.product_id.standard_ratio * self.quantity
        return result

